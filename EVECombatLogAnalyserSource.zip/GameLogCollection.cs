namespace CombatLog
{
    using System;
    using System.Collections;
	using System.IO;
	using System.Text.RegularExpressions;
	using Microsoft.Win32;
	using System.Diagnostics;
    
    
    /// <summary>
    /// Strongly typed collection of CombatLog.GameLog.
    /// </summary>
    public class GameLogCollection : System.Collections.CollectionBase
    {

        
		// HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\EVE - C:\Program Files\CCP\EVE\uninst.exe
		//
		// Chat logs in {PathEve}\Capture\ChatLogs

		private string uninstallRegKeyDir = @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\EVE";
		private string uninstallRegKeyVal = "UninstallString";
		private string chatLogDir = @"\capture\GameLogs\";
		private string installDirectory;

		//
		// Event Handler
		//
		public delegate void LogFileProcessedEvent(object Sender, GameLog LogFileLoadedEventArgs, int Current, int Total);
		public event LogFileProcessedEvent LogFileProcessed_Event = null;

		public delegate void LogFileProcessingComplete(object Sender, System.EventArgs e);
		public event LogFileProcessingComplete ProcessingComplete_Event = null;

		public delegate void LogFileProcessingStarting(object Sender, int FileCount);
		public event LogFileProcessingStarting ProcessingStarted_Event = null;

		public CombatLogCacheCollection LogCache = null;
        
		private string ReadRegKey(string KeyName, string SubKeyName)
		{
			string s = "";

			try 
			{
				RegistryKey d = Registry.LocalMachine.OpenSubKey(KeyName);

				s = (string)d.GetValue(SubKeyName);
			}
			catch (Exception e)
			{
				Console.WriteLine("Error: {0}", e);
			}

			return s;
		}

        /// <summary>
        /// Default constructor.
        /// </summary>
        public GameLogCollection() : 
                base()
        {
			string s = ReadRegKey(uninstallRegKeyDir, uninstallRegKeyVal);

			//
			// The registry key returns a path to the uninstall executable so we need to strip the uninstall.exe from the string
			//

			installDirectory = s.Substring(0, s.IndexOf("Uninstall.exe") - 1) + chatLogDir;
		}

		public string[] GetUniqueListeners()
		{
			Hashtable Listeners = new Hashtable();

			foreach ( GameLog g in this.List )
			{
				try
				{
					Listeners.Add(g.Listener, "foo");
				}
				catch
				{
				}
			}

			string[] l = new string[Listeners.Count];

			int i = 0;
			foreach ( object k in Listeners.Keys )
				l[i++] = k.ToString();

			return l;
		}

		public GameLogCollection FilterBy(string Listener)
		{
			GameLogCollection gc = new GameLogCollection();

			foreach ( GameLog l in this.List )
			{
				if ( l.Listener == Listener )
					gc.Add(l);
			}

			return gc;
		}

		public GameLogCollection FilterBy(int AgeInDays)
		{
			GameLogCollection gc = new GameLogCollection();

			foreach ( GameLog l in this.List )
			{
				TimeSpan t = new TimeSpan(AgeInDays,0,0,0);

				if ( l.SessionStartedDTM >= DateTime.Now.Subtract(t) )
					gc.Add(l);
			}

			return gc;
		}

		public GameLogCollection FilterBy(string Listener, int AgeInDays)
		{
			GameLogCollection ByListener = this.FilterBy(Listener);

			return ByListener.FilterBy(AgeInDays);
		}

		public void EnumerateGameLogDir()
		{
			int CurrentFileNo = 0;
			int TotalFileCount = 0;

			DirectoryInfo TheFolder = new DirectoryInfo(installDirectory);

			if (TheFolder.Exists)
			{
				FileInfo[] f = TheFolder.GetFiles();
				TotalFileCount = f.Length;

				if ( this.ProcessingStarted_Event != null )
					this.ProcessingStarted_Event(this, f.Length);

				foreach (FileInfo fi in f )
				{
					GameLog cl = new GameLog(fi.FullName);
					cl.CreationTime = fi.CreationTime;
					cl.FileSize = fi.Length;
					cl.LeafName = fi.Name;

					// Do we have this file cached?
					#region Process the log file
					if ( LogCache != null )
					{
						if ( LogCache.FileCached(cl.FileName) )
						{
							if ( LogCache.IsCombatLog(cl.FileName) )
							{
								// cl.GetHeaders();
								cl.Listener = LogCache[cl.FileName].Character;
								cl.SessionStartedDTM = LogCache[cl.FileName].CreationTime;
								
								this.Add(cl);
							}
						}
						else
						{
							if ( cl.IsCombatLog() )
							{
								try
								{
									cl.GetHeaders();
									CombatLogEntryCollection cLog = cl.GetCombatEntries();

									CombatLogCache clc = new CombatLogCache(cl.FileName, cl.FileSize, cl.CreationTime, true);
									clc.Character = cl.Listener;
				
									if ( cLog != null )
									{
										Debug.WriteLine("Attempting to retrieve unique lists");
										clc.WeaponsUsed = cLog.GetUniqueWeaponsList();
										clc.TargetsAttacked = cLog.GetUniqueTargets();
										clc.HitTypes = cLog.GetUniqueHitTypes();
									}

									this.Add(cl);
									LogCache.Add(clc);
								}
								catch (Exception e)
								{
									Debug.WriteLine("Error getting headers for non-cached file: " + e.ToString());
								}
							}
							else
								LogCache.Add(new CombatLogCache(cl.FileName, cl.FileSize, cl.CreationTime, false));
						}
					}
					else
					{
						// This is a new file that is not cached
						if ( cl.IsCombatLog() )
						{
							try
							{
								cl.GetHeaders();
								this.Add(cl);
							}
							catch (Exception e)
							{
								Debug.WriteLine("Error getting headers: " + e.ToString());
								// Do nothing, the file will not be added to the collection
							}
						}
					}
					#endregion

					if ( this.LogFileProcessed_Event != null )
						this.LogFileProcessed_Event(this, cl, CurrentFileNo++, TotalFileCount);
				}

			}

			if ( ProcessingComplete_Event != null )
				this.ProcessingComplete_Event(this, new System.EventArgs());
		}

        /// <summary>
        /// Gets or sets the value of the CombatLog.GameLog at a specific position in the GameLogCollection.
        /// </summary>
        public CombatLog.GameLog this[int index]
        {
            get
            {
                return ((CombatLog.GameLog)(this.List[index]));
            }
            set
            {
                this.List[index] = value;
            }
        }
        
        /// <summary>
        /// Append a CombatLog.GameLog entry to this collection.
        /// </summary>
        /// <param name="value">CombatLog.GameLog instance.</param>
        /// <returns>The position into which the new element was inserted.</returns>
        public int Add(CombatLog.GameLog value)
        {
            return this.List.Add(value);
        }
        
        /// <summary>
        /// Determines whether a specified CombatLog.GameLog instance is in this collection.
        /// </summary>
        /// <param name="value">CombatLog.GameLog instance to search for.</param>
        /// <returns>True if the CombatLog.GameLog instance is in the collection; otherwise false.</returns>
        public bool Contains(CombatLog.GameLog value)
        {
            return this.List.Contains(value);
        }
        
        /// <summary>
        /// Retrieve the index a specified CombatLog.GameLog instance is in this collection.
        /// </summary>
        /// <param name="value">CombatLog.GameLog instance to find.</param>
        /// <returns>The zero-based index of the specified CombatLog.GameLog instance. If the object is not found, the return value is -1.</returns>
        public int IndexOf(CombatLog.GameLog value)
        {
            return this.List.IndexOf(value);
        }
        
        /// <summary>
        /// Removes a specified CombatLog.GameLog instance from this collection.
        /// </summary>
        /// <param name="value">The CombatLog.GameLog instance to remove.</param>
        public void Remove(CombatLog.GameLog value)
        {
            this.List.Remove(value);
        }
        
        /// <summary>
        /// Returns an enumerator that can iterate through the CombatLog.GameLog instance.
        /// </summary>
        /// <returns>An CombatLog.GameLog's enumerator.</returns>
        public new GameLogCollectionEnumerator GetEnumerator()
        {
            return new GameLogCollectionEnumerator(this);
        }
        
        /// <summary>
        /// Insert a CombatLog.GameLog instance into this collection at a specified index.
        /// </summary>
        /// <param name="index">Zero-based index.</param>
        /// <param name="value">The CombatLog.GameLog instance to insert.</param>
        public void Insert(int index, CombatLog.GameLog value)
        {
            this.List.Insert(index, value);
        }
        
        /// <summary>
        /// Strongly typed enumerator of CombatLog.GameLog.
        /// </summary>
        public class GameLogCollectionEnumerator : object, System.Collections.IEnumerator
        {
            
            /// <summary>
            /// Current index
            /// </summary>
            private int _index;
            
            /// <summary>
            /// Current element pointed to.
            /// </summary>
            private CombatLog.GameLog _currentElement;
            
            /// <summary>
            /// Collection to enumerate.
            /// </summary>
            private GameLogCollection _collection;
            
            /// <summary>
            /// Default constructor for enumerator.
            /// </summary>
            /// <param name="collection">Instance of the collection to enumerate.</param>
            internal GameLogCollectionEnumerator(GameLogCollection collection)
            {
                _index = -1;
                _collection = collection;
            }
            
            /// <summary>
            /// Gets the CombatLog.GameLog object in the enumerated GameLogCollection currently indexed by this instance.
            /// </summary>
            public CombatLog.GameLog Current
            {
                get
                {
                    if (((_index == -1) 
                                || (_index >= _collection.Count)))
                    {
                        throw new System.IndexOutOfRangeException("Enumerator not started.");
                    }
                    else
                    {
                        return _currentElement;
                    }
                }
            }
            
            /// <summary>
            /// Gets the current element in the collection.
            /// </summary>
            object IEnumerator.Current
            {
                get
                {
                    if (((_index == -1) 
                                || (_index >= _collection.Count)))
                    {
                        throw new System.IndexOutOfRangeException("Enumerator not started.");
                    }
                    else
                    {
                        return _currentElement;
                    }
                }
            }
            
            /// <summary>
            /// Reset the cursor, so it points to the beginning of the enumerator.
            /// </summary>
            public void Reset()
            {
                _index = -1;
                _currentElement = null;
            }
            
            /// <summary>
            /// Advances the enumerator to the next queue of the enumeration, if one is currently available.
            /// </summary>
            /// <returns>true, if the enumerator was succesfully advanced to the next queue; false, if the enumerator has reached the end of the enumeration.</returns>
            public bool MoveNext()
            {
                if ((_index 
                            < (_collection.Count - 1)))
                {
                    _index = (_index + 1);
                    _currentElement = this._collection[_index];
                    return true;
                }
                _index = _collection.Count;
                return false;
            }

        }
    }
}
