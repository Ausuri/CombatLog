using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;
using System.Text;

namespace CombatLog
{
	/// <summary>
	/// Summary description for Form2.
	/// </summary>
	public class Form2 : System.Windows.Forms.Form
	{

		private GraphItemCollection GraphControls = new GraphItemCollection();

		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.Label lblWeaponFilter;
		private System.Windows.Forms.Button btnWeaponFilter;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Button btnHitTypeMenu;
		private System.Windows.Forms.Button btnTargetFilter;
		private System.Windows.Forms.Label lblHitType;
		private System.Windows.Forms.Label lblTargetFilter;
		private System.Windows.Forms.ListView listViewCombatSummary;
		private System.Windows.Forms.ColumnHeader columnHeader3;
		private System.Windows.Forms.ColumnHeader columnHeader4;
		private System.Windows.Forms.ColumnHeader columnHeader5;
		private System.Windows.Forms.ColumnHeader columnHeader6;
		private System.Windows.Forms.ColumnHeader columnHeader7;
		private System.Windows.Forms.ListView listView2;
		private System.Windows.Forms.ColumnHeader columnHeader8;
		private System.Windows.Forms.ColumnHeader columnHeader9;
		private System.Windows.Forms.ColumnHeader columnHeader15;
		private System.Windows.Forms.ColumnHeader columnHeader16;
		private System.Windows.Forms.ColumnHeader columnHeader10;
		private System.Windows.Forms.ColumnHeader columnHeader11;
		private System.Windows.Forms.ColumnHeader columnHeader12;
		private System.Windows.Forms.ColumnHeader columnHeader13;
		private System.Windows.Forms.ColumnHeader columnHeader14;
		private TD.SandDock.SandDockManager sandDockManager1;
		private TD.SandDock.DockContainer leftSandDock;
		private TD.SandDock.DockContainer rightSandDock;
		private TD.SandDock.DockContainer bottomSandDock;
		private TD.SandDock.DockContainer topSandDock;
		private TD.SandDock.DockControl dockControl2;
		private TD.SandDock.DockControl dockControl3;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.RichTextBox richTextBoxSummary;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.Windows.Forms.ContextMenu contextMenuWeaponx;
		private System.Windows.Forms.ContextMenu contextMenuHitTypesx;
		private System.Windows.Forms.ContextMenu contextMenuTargetx;
		private TD.SandBar.SandBarManager sandBarManager1;
		private TD.SandBar.ToolBarContainer leftSandBarDock;
		private TD.SandBar.ToolBarContainer rightSandBarDock;
		private TD.SandBar.ToolBarContainer bottomSandBarDock;
		private TD.SandBar.ToolBarContainer topSandBarDock;
		private TD.SandBar.MenuBar menuBar1;
		private TD.SandBar.ContextMenuBarItem contextMenuCombatSummary;
		private TD.SandBar.MenuButtonItem menuItemFindWeapon;
		private TD.SandBar.MenuButtonItem menuItemFindTarget;
		private TD.SandBar.ContextMenuBarItem contextMenuBarItem1;
		private TD.SandBar.MenuButtonItem menuButtonItem1;
		private TD.SandBar.MenuButtonItem menuButtonItem2;
		private TD.SandBar.ContextMenuBarItem contextMenuWeapon;
		private TD.SandBar.MenuButtonItem menuButtonItem3;
		private TD.SandBar.ContextMenuBarItem contextMenuHitTypes;
		private TD.SandBar.ContextMenuBarItem contextMenuTarget;
		private TD.SandBar.MenuButtonItem menuButtonItem4;
		private TD.SandBar.MenuButtonItem menuButtonItem5;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Panel panelMainMiddle;
		private System.Windows.Forms.Splitter splitter1;

		public event GameLog.ProcessingStartedEvent CombatLogProcessStarted = null;
		public event GameLog.ProcessingUpdateEvent CombatLogProcessUpdate = null;
		public event GameLog.ProcessingCompleteEvent CombatLogProcessComplete = null;

		public GameLog ThisGameLog;
		private System.Windows.Forms.MenuItem menuItem4;
		private System.Windows.Forms.MenuItem menuItem5;
		private System.Windows.Forms.ContextMenu contextMenuItemInfo;
		public GameLogCollection AllGameLogs;

		public Form2()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form2));
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.lblWeaponFilter = new System.Windows.Forms.Label();
			this.btnWeaponFilter = new System.Windows.Forms.Button();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.btnHitTypeMenu = new System.Windows.Forms.Button();
			this.btnTargetFilter = new System.Windows.Forms.Button();
			this.lblHitType = new System.Windows.Forms.Label();
			this.lblTargetFilter = new System.Windows.Forms.Label();
			this.listViewCombatSummary = new System.Windows.Forms.ListView();
			this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader5 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader6 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader7 = new System.Windows.Forms.ColumnHeader();
			this.contextMenuItemInfo = new System.Windows.Forms.ContextMenu();
			this.menuItem4 = new System.Windows.Forms.MenuItem();
			this.menuItem5 = new System.Windows.Forms.MenuItem();
			this.listView2 = new System.Windows.Forms.ListView();
			this.columnHeader8 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader9 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader15 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader16 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader10 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader11 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader12 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader13 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader14 = new System.Windows.Forms.ColumnHeader();
			this.sandDockManager1 = new TD.SandDock.SandDockManager();
			this.leftSandDock = new TD.SandDock.DockContainer();
			this.rightSandDock = new TD.SandDock.DockContainer();
			this.dockControl2 = new TD.SandDock.DockControl();
			this.dockControl3 = new TD.SandDock.DockControl();
			this.richTextBoxSummary = new System.Windows.Forms.RichTextBox();
			this.bottomSandDock = new TD.SandDock.DockContainer();
			this.topSandDock = new TD.SandDock.DockContainer();
			this.contextMenuWeaponx = new System.Windows.Forms.ContextMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.contextMenuHitTypesx = new System.Windows.Forms.ContextMenu();
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.contextMenuTargetx = new System.Windows.Forms.ContextMenu();
			this.menuItem3 = new System.Windows.Forms.MenuItem();
			this.sandBarManager1 = new TD.SandBar.SandBarManager();
			this.bottomSandBarDock = new TD.SandBar.ToolBarContainer();
			this.leftSandBarDock = new TD.SandBar.ToolBarContainer();
			this.rightSandBarDock = new TD.SandBar.ToolBarContainer();
			this.topSandBarDock = new TD.SandBar.ToolBarContainer();
			this.menuBar1 = new TD.SandBar.MenuBar();
			this.contextMenuWeapon = new TD.SandBar.ContextMenuBarItem();
			this.menuButtonItem3 = new TD.SandBar.MenuButtonItem();
			this.contextMenuHitTypes = new TD.SandBar.ContextMenuBarItem();
			this.menuButtonItem4 = new TD.SandBar.MenuButtonItem();
			this.contextMenuTarget = new TD.SandBar.ContextMenuBarItem();
			this.menuButtonItem5 = new TD.SandBar.MenuButtonItem();
			this.contextMenuCombatSummary = new TD.SandBar.ContextMenuBarItem();
			this.menuItemFindWeapon = new TD.SandBar.MenuButtonItem();
			this.menuItemFindTarget = new TD.SandBar.MenuButtonItem();
			this.contextMenuBarItem1 = new TD.SandBar.ContextMenuBarItem();
			this.menuButtonItem1 = new TD.SandBar.MenuButtonItem();
			this.menuButtonItem2 = new TD.SandBar.MenuButtonItem();
			this.panel1 = new System.Windows.Forms.Panel();
			this.panel2 = new System.Windows.Forms.Panel();
			this.panelMainMiddle = new System.Windows.Forms.Panel();
			this.splitter1 = new System.Windows.Forms.Splitter();
			this.groupBox2.SuspendLayout();
			this.rightSandDock.SuspendLayout();
			this.dockControl3.SuspendLayout();
			this.topSandBarDock.SuspendLayout();
			this.panel1.SuspendLayout();
			this.panel2.SuspendLayout();
			this.panelMainMiddle.SuspendLayout();
			this.SuspendLayout();
			// 
			// groupBox2
			// 
			this.groupBox2.BackColor = System.Drawing.SystemColors.ControlLight;
			this.groupBox2.Controls.Add(this.lblWeaponFilter);
			this.groupBox2.Controls.Add(this.btnWeaponFilter);
			this.groupBox2.Controls.Add(this.label3);
			this.groupBox2.Controls.Add(this.label4);
			this.groupBox2.Controls.Add(this.label5);
			this.groupBox2.Controls.Add(this.btnHitTypeMenu);
			this.groupBox2.Controls.Add(this.btnTargetFilter);
			this.groupBox2.Controls.Add(this.lblHitType);
			this.groupBox2.Controls.Add(this.lblTargetFilter);
			this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.groupBox2.Location = new System.Drawing.Point(0, 0);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(642, 96);
			this.groupBox2.TabIndex = 3;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Display Filters";
			// 
			// lblWeaponFilter
			// 
			this.lblWeaponFilter.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.lblWeaponFilter.BackColor = System.Drawing.SystemColors.ControlLightLight;
			this.lblWeaponFilter.Location = new System.Drawing.Point(72, 16);
			this.lblWeaponFilter.Name = "lblWeaponFilter";
			this.lblWeaponFilter.Size = new System.Drawing.Size(240, 23);
			this.lblWeaponFilter.TabIndex = 4;
			this.lblWeaponFilter.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// btnWeaponFilter
			// 
			this.btnWeaponFilter.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btnWeaponFilter.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnWeaponFilter.Location = new System.Drawing.Point(320, 16);
			this.btnWeaponFilter.Name = "btnWeaponFilter";
			this.btnWeaponFilter.Size = new System.Drawing.Size(24, 23);
			this.btnWeaponFilter.TabIndex = 3;
			this.btnWeaponFilter.Text = "...";
			this.btnWeaponFilter.Click += new System.EventHandler(this.btnWeaponFilter_Click);
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(8, 16);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(56, 23);
			this.label3.TabIndex = 1;
			this.label3.Text = "Weapon";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(8, 40);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(56, 23);
			this.label4.TabIndex = 1;
			this.label4.Text = "Hit Type";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(8, 64);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(56, 23);
			this.label5.TabIndex = 1;
			this.label5.Text = "Target";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// btnHitTypeMenu
			// 
			this.btnHitTypeMenu.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btnHitTypeMenu.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnHitTypeMenu.Location = new System.Drawing.Point(320, 40);
			this.btnHitTypeMenu.Name = "btnHitTypeMenu";
			this.btnHitTypeMenu.Size = new System.Drawing.Size(24, 23);
			this.btnHitTypeMenu.TabIndex = 3;
			this.btnHitTypeMenu.Text = "...";
			this.btnHitTypeMenu.Click += new System.EventHandler(this.btnHitTypeMenu_Click);
			// 
			// btnTargetFilter
			// 
			this.btnTargetFilter.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btnTargetFilter.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnTargetFilter.Location = new System.Drawing.Point(320, 64);
			this.btnTargetFilter.Name = "btnTargetFilter";
			this.btnTargetFilter.Size = new System.Drawing.Size(24, 23);
			this.btnTargetFilter.TabIndex = 3;
			this.btnTargetFilter.Text = "...";
			this.btnTargetFilter.Click += new System.EventHandler(this.btnTargetFilter_Click);
			// 
			// lblHitType
			// 
			this.lblHitType.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.lblHitType.BackColor = System.Drawing.SystemColors.ControlLightLight;
			this.lblHitType.Location = new System.Drawing.Point(72, 40);
			this.lblHitType.Name = "lblHitType";
			this.lblHitType.Size = new System.Drawing.Size(240, 23);
			this.lblHitType.TabIndex = 4;
			this.lblHitType.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// lblTargetFilter
			// 
			this.lblTargetFilter.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.lblTargetFilter.BackColor = System.Drawing.SystemColors.ControlLightLight;
			this.lblTargetFilter.Location = new System.Drawing.Point(72, 64);
			this.lblTargetFilter.Name = "lblTargetFilter";
			this.lblTargetFilter.Size = new System.Drawing.Size(240, 23);
			this.lblTargetFilter.TabIndex = 4;
			this.lblTargetFilter.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// listViewCombatSummary
			// 
			this.listViewCombatSummary.AllowColumnReorder = true;
			this.listViewCombatSummary.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																									this.columnHeader3,
																									this.columnHeader4,
																									this.columnHeader5,
																									this.columnHeader6,
																									this.columnHeader7});
			this.listViewCombatSummary.ContextMenu = this.contextMenuItemInfo;
			this.listViewCombatSummary.Dock = System.Windows.Forms.DockStyle.Fill;
			this.listViewCombatSummary.Enabled = false;
			this.listViewCombatSummary.FullRowSelect = true;
			this.listViewCombatSummary.HideSelection = false;
			this.listViewCombatSummary.Location = new System.Drawing.Point(0, 0);
			this.listViewCombatSummary.Name = "listViewCombatSummary";
			this.listViewCombatSummary.Size = new System.Drawing.Size(642, 330);
			this.listViewCombatSummary.TabIndex = 4;
			this.listViewCombatSummary.View = System.Windows.Forms.View.Details;
			// 
			// columnHeader3
			// 
			this.columnHeader3.Text = "Date/Time";
			this.columnHeader3.Width = 126;
			// 
			// columnHeader4
			// 
			this.columnHeader4.Text = "Weapon";
			this.columnHeader4.Width = 185;
			// 
			// columnHeader5
			// 
			this.columnHeader5.Text = "Hit Type";
			this.columnHeader5.Width = 115;
			// 
			// columnHeader6
			// 
			this.columnHeader6.Text = "Target";
			this.columnHeader6.Width = 142;
			// 
			// columnHeader7
			// 
			this.columnHeader7.Text = "Damage";
			this.columnHeader7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// contextMenuItemInfo
			// 
			this.contextMenuItemInfo.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																								this.menuItem4,
																								this.menuItem5});
			// 
			// menuItem4
			// 
			this.menuItem4.Index = 0;
			this.menuItem4.Text = "Weapon Details";
			this.menuItem4.Click += new System.EventHandler(this.menuItem4_Click);
			// 
			// menuItem5
			// 
			this.menuItem5.Index = 1;
			this.menuItem5.Text = "Target Details";
			this.menuItem5.Click += new System.EventHandler(this.menuItem5_Click);
			// 
			// listView2
			// 
			this.listView2.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																						this.columnHeader8,
																						this.columnHeader9,
																						this.columnHeader15,
																						this.columnHeader16,
																						this.columnHeader10,
																						this.columnHeader11,
																						this.columnHeader12,
																						this.columnHeader13,
																						this.columnHeader14});
			this.listView2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.listView2.Enabled = false;
			this.listView2.FullRowSelect = true;
			this.listView2.Location = new System.Drawing.Point(0, 0);
			this.listView2.Name = "listView2";
			this.listView2.Size = new System.Drawing.Size(642, 100);
			this.listView2.TabIndex = 5;
			this.listView2.View = System.Windows.Forms.View.Details;
			// 
			// columnHeader8
			// 
			this.columnHeader8.Text = "Weapon Name";
			this.columnHeader8.Width = 145;
			// 
			// columnHeader9
			// 
			this.columnHeader9.Text = "Fired";
			this.columnHeader9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.columnHeader9.Width = 50;
			// 
			// columnHeader15
			// 
			this.columnHeader15.Text = "Hit";
			this.columnHeader15.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.columnHeader15.Width = 46;
			// 
			// columnHeader16
			// 
			this.columnHeader16.Text = "Missed";
			this.columnHeader16.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.columnHeader16.Width = 55;
			// 
			// columnHeader10
			// 
			this.columnHeader10.Text = "Tot. Dmg";
			this.columnHeader10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.columnHeader10.Width = 66;
			// 
			// columnHeader11
			// 
			this.columnHeader11.Text = "Avg. Dmg";
			this.columnHeader11.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.columnHeader11.Width = 86;
			// 
			// columnHeader12
			// 
			this.columnHeader12.Text = "% Hit";
			this.columnHeader12.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// columnHeader13
			// 
			this.columnHeader13.Text = "% Missed";
			this.columnHeader13.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// columnHeader14
			// 
			this.columnHeader14.Text = "Duration";
			this.columnHeader14.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// sandDockManager1
			// 
			this.sandDockManager1.OwnerForm = this;
			// 
			// leftSandDock
			// 
			this.leftSandDock.Dock = System.Windows.Forms.DockStyle.Left;
			this.leftSandDock.Guid = new System.Guid("ae143c5f-b3cc-4695-8e54-ff28ca05e56b");
			this.leftSandDock.LayoutSystem = new TD.SandDock.SplitLayoutSystem(250, 400);
			this.leftSandDock.Location = new System.Drawing.Point(0, 24);
			this.leftSandDock.Manager = this.sandDockManager1;
			this.leftSandDock.Name = "leftSandDock";
			this.leftSandDock.Size = new System.Drawing.Size(0, 526);
			this.leftSandDock.TabIndex = 6;
			// 
			// rightSandDock
			// 
			this.rightSandDock.Controls.Add(this.dockControl2);
			this.rightSandDock.Controls.Add(this.dockControl3);
			this.rightSandDock.Dock = System.Windows.Forms.DockStyle.Right;
			this.rightSandDock.Guid = new System.Guid("382fac09-bc60-42b2-895f-d9bf3cefd19a");
			this.rightSandDock.LayoutSystem = new TD.SandDock.SplitLayoutSystem(250, 400, System.Windows.Forms.Orientation.Horizontal, new TD.SandDock.LayoutSystemBase[] {
																																											  new TD.SandDock.ControlLayoutSystem(250, 526, new TD.SandDock.DockControl[] {
																																																															  this.dockControl2,
																																																															  this.dockControl3}, this.dockControl2)});
			this.rightSandDock.Location = new System.Drawing.Point(642, 24);
			this.rightSandDock.Manager = this.sandDockManager1;
			this.rightSandDock.MaximumSize = 600;
			this.rightSandDock.Name = "rightSandDock";
			this.rightSandDock.Size = new System.Drawing.Size(254, 526);
			this.rightSandDock.TabIndex = 7;
			// 
			// dockControl2
			// 
			this.dockControl2.AutoScroll = true;
			this.dockControl2.Closable = false;
			this.dockControl2.Guid = new System.Guid("7e90cf0c-2d67-4107-b6c2-e6a118e7d854");
			this.dockControl2.Location = new System.Drawing.Point(4, 18);
			this.dockControl2.Name = "dockControl2";
			this.dockControl2.Size = new System.Drawing.Size(250, 485);
			this.dockControl2.TabIndex = 0;
			this.dockControl2.Text = "Damage by Hit Type";
			// 
			// dockControl3
			// 
			this.dockControl3.AutoScroll = true;
			this.dockControl3.Closable = false;
			this.dockControl3.Controls.Add(this.richTextBoxSummary);
			this.dockControl3.Guid = new System.Guid("758af593-7eb6-4af5-856f-c31a8803ea0e");
			this.dockControl3.Location = new System.Drawing.Point(4, 18);
			this.dockControl3.Name = "dockControl3";
			this.dockControl3.Size = new System.Drawing.Size(250, 485);
			this.dockControl3.TabIndex = 1;
			this.dockControl3.Text = "Summary Description";
			// 
			// richTextBoxSummary
			// 
			this.richTextBoxSummary.Dock = System.Windows.Forms.DockStyle.Fill;
			this.richTextBoxSummary.Location = new System.Drawing.Point(0, 0);
			this.richTextBoxSummary.Name = "richTextBoxSummary";
			this.richTextBoxSummary.ReadOnly = true;
			this.richTextBoxSummary.Size = new System.Drawing.Size(250, 485);
			this.richTextBoxSummary.TabIndex = 0;
			this.richTextBoxSummary.Text = "richTextBoxSummary";
			// 
			// bottomSandDock
			// 
			this.bottomSandDock.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.bottomSandDock.Guid = new System.Guid("b276b6ca-915a-42cb-b181-22e5a4d7f9ee");
			this.bottomSandDock.LayoutSystem = new TD.SandDock.SplitLayoutSystem(250, 400);
			this.bottomSandDock.Location = new System.Drawing.Point(0, 550);
			this.bottomSandDock.Manager = this.sandDockManager1;
			this.bottomSandDock.Name = "bottomSandDock";
			this.bottomSandDock.Size = new System.Drawing.Size(896, 0);
			this.bottomSandDock.TabIndex = 8;
			// 
			// topSandDock
			// 
			this.topSandDock.Dock = System.Windows.Forms.DockStyle.Top;
			this.topSandDock.Guid = new System.Guid("40e47a20-269a-47ca-881d-71d1abdc6ba5");
			this.topSandDock.LayoutSystem = new TD.SandDock.SplitLayoutSystem(250, 400);
			this.topSandDock.Location = new System.Drawing.Point(0, 24);
			this.topSandDock.Manager = this.sandDockManager1;
			this.topSandDock.Name = "topSandDock";
			this.topSandDock.Size = new System.Drawing.Size(896, 0);
			this.topSandDock.TabIndex = 9;
			// 
			// contextMenuWeaponx
			// 
			this.contextMenuWeaponx.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																							   this.menuItem1});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.Text = "All";
			// 
			// contextMenuHitTypesx
			// 
			this.contextMenuHitTypesx.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																								 this.menuItem2});
			// 
			// menuItem2
			// 
			this.menuItem2.Index = 0;
			this.menuItem2.Text = "All";
			// 
			// contextMenuTargetx
			// 
			this.contextMenuTargetx.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																							   this.menuItem3});
			// 
			// menuItem3
			// 
			this.menuItem3.Index = 0;
			this.menuItem3.Text = "All";
			// 
			// sandBarManager1
			// 
			this.sandBarManager1.BottomContainer = this.bottomSandBarDock;
			this.sandBarManager1.LeftContainer = this.leftSandBarDock;
			this.sandBarManager1.OwnerForm = this;
			this.sandBarManager1.RightContainer = this.rightSandBarDock;
			this.sandBarManager1.TopContainer = this.topSandBarDock;
			// 
			// bottomSandBarDock
			// 
			this.bottomSandBarDock.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.bottomSandBarDock.Location = new System.Drawing.Point(0, 550);
			this.bottomSandBarDock.Manager = this.sandBarManager1;
			this.bottomSandBarDock.Name = "bottomSandBarDock";
			this.bottomSandBarDock.Size = new System.Drawing.Size(896, 0);
			this.bottomSandBarDock.TabIndex = 12;
			// 
			// leftSandBarDock
			// 
			this.leftSandBarDock.Dock = System.Windows.Forms.DockStyle.Left;
			this.leftSandBarDock.Location = new System.Drawing.Point(0, 24);
			this.leftSandBarDock.Manager = this.sandBarManager1;
			this.leftSandBarDock.Name = "leftSandBarDock";
			this.leftSandBarDock.Size = new System.Drawing.Size(0, 526);
			this.leftSandBarDock.TabIndex = 10;
			// 
			// rightSandBarDock
			// 
			this.rightSandBarDock.Dock = System.Windows.Forms.DockStyle.Right;
			this.rightSandBarDock.Location = new System.Drawing.Point(896, 24);
			this.rightSandBarDock.Manager = this.sandBarManager1;
			this.rightSandBarDock.Name = "rightSandBarDock";
			this.rightSandBarDock.Size = new System.Drawing.Size(0, 526);
			this.rightSandBarDock.TabIndex = 11;
			// 
			// topSandBarDock
			// 
			this.topSandBarDock.Controls.Add(this.menuBar1);
			this.topSandBarDock.Dock = System.Windows.Forms.DockStyle.Top;
			this.topSandBarDock.Location = new System.Drawing.Point(0, 0);
			this.topSandBarDock.Manager = this.sandBarManager1;
			this.topSandBarDock.Name = "topSandBarDock";
			this.topSandBarDock.Size = new System.Drawing.Size(896, 24);
			this.topSandBarDock.TabIndex = 13;
			// 
			// menuBar1
			// 
			this.menuBar1.Buttons.AddRange(new TD.SandBar.ToolbarItemBase[] {
																				this.contextMenuWeapon,
																				this.contextMenuHitTypes,
																				this.contextMenuTarget});
			this.menuBar1.Guid = new System.Guid("ceb8862f-b368-4931-9bde-7bf71b610201");
			this.menuBar1.IsOpen = true;
			this.menuBar1.Location = new System.Drawing.Point(2, 0);
			this.menuBar1.Name = "menuBar1";
			this.menuBar1.Size = new System.Drawing.Size(894, 24);
			this.menuBar1.TabIndex = 0;
			this.menuBar1.Visible = false;
			// 
			// contextMenuWeapon
			// 
			this.contextMenuWeapon.MenuItems.AddRange(new TD.SandBar.MenuButtonItem[] {
																						  this.menuButtonItem3});
			this.contextMenuWeapon.Text = "contextMenuWeapon";
			// 
			// menuButtonItem3
			// 
			this.menuButtonItem3.Text = "All";
			// 
			// contextMenuHitTypes
			// 
			this.contextMenuHitTypes.MenuItems.AddRange(new TD.SandBar.MenuButtonItem[] {
																							this.menuButtonItem4});
			this.contextMenuHitTypes.Text = "contextMenuHitTypes";
			// 
			// menuButtonItem4
			// 
			this.menuButtonItem4.Text = "All";
			// 
			// contextMenuTarget
			// 
			this.contextMenuTarget.MenuItems.AddRange(new TD.SandBar.MenuButtonItem[] {
																						  this.menuButtonItem5});
			this.contextMenuTarget.Text = "contextMenuTarget";
			// 
			// menuButtonItem5
			// 
			this.menuButtonItem5.Text = "All";
			// 
			// contextMenuCombatSummary
			// 
			this.contextMenuCombatSummary.MenuItems.AddRange(new TD.SandBar.MenuButtonItem[] {
																								 this.menuItemFindWeapon,
																								 this.menuItemFindTarget});
			this.contextMenuCombatSummary.Text = "(contextMenuCombatSummary)";
			// 
			// menuItemFindWeapon
			// 
			this.menuItemFindWeapon.Text = "Find %0 on EVE-I OE";
			// 
			// menuItemFindTarget
			// 
			this.menuItemFindTarget.Text = "Find %0 on EVE-I OE";
			// 
			// contextMenuBarItem1
			// 
			this.contextMenuBarItem1.MenuItems.AddRange(new TD.SandBar.MenuButtonItem[] {
																							this.menuButtonItem1,
																							this.menuButtonItem2});
			this.contextMenuBarItem1.Text = "(contextMenuCombatSummary)";
			// 
			// menuButtonItem1
			// 
			this.menuButtonItem1.Text = "Find %0 on EVE-I OE";
			// 
			// menuButtonItem2
			// 
			this.menuButtonItem2.Text = "Find %0 on EVE-I OE";
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.groupBox2);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel1.Location = new System.Drawing.Point(0, 24);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(642, 96);
			this.panel1.TabIndex = 14;
			// 
			// panel2
			// 
			this.panel2.Controls.Add(this.listView2);
			this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel2.Location = new System.Drawing.Point(0, 450);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(642, 100);
			this.panel2.TabIndex = 15;
			// 
			// panelMainMiddle
			// 
			this.panelMainMiddle.Controls.Add(this.listViewCombatSummary);
			this.panelMainMiddle.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panelMainMiddle.Location = new System.Drawing.Point(0, 120);
			this.panelMainMiddle.Name = "panelMainMiddle";
			this.panelMainMiddle.Size = new System.Drawing.Size(642, 330);
			this.panelMainMiddle.TabIndex = 16;
			// 
			// splitter1
			// 
			this.splitter1.BackColor = System.Drawing.SystemColors.ControlDark;
			this.splitter1.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.splitter1.Location = new System.Drawing.Point(0, 447);
			this.splitter1.Name = "splitter1";
			this.splitter1.Size = new System.Drawing.Size(642, 3);
			this.splitter1.TabIndex = 17;
			this.splitter1.TabStop = false;
			// 
			// Form2
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(896, 550);
			this.Controls.Add(this.splitter1);
			this.Controls.Add(this.panelMainMiddle);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.leftSandDock);
			this.Controls.Add(this.rightSandDock);
			this.Controls.Add(this.bottomSandDock);
			this.Controls.Add(this.topSandDock);
			this.Controls.Add(this.leftSandBarDock);
			this.Controls.Add(this.rightSandBarDock);
			this.Controls.Add(this.bottomSandBarDock);
			this.Controls.Add(this.topSandBarDock);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "Form2";
			this.Text = "Form2";
			this.Load += new System.EventHandler(this.Form2_Load);
			this.groupBox2.ResumeLayout(false);
			this.rightSandDock.ResumeLayout(false);
			this.dockControl3.ResumeLayout(false);
			this.topSandBarDock.ResumeLayout(false);
			this.panel1.ResumeLayout(false);
			this.panel2.ResumeLayout(false);
			this.panelMainMiddle.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void Form2_Load(object sender, System.EventArgs e)
		{
			if ( ThisGameLog == null )
			{
				MessageBox.Show("Serious problem, no gamelog details supplied!");
				return;
			}

			GameLog g = ThisGameLog;

			g.GetFile();

			EnableComponents();

			DoCombatLog(g);
		}


		public void ExportFile(string FileName, int FilterIndex)
		{
			Debug.WriteLine("Request to export file: " + FileName + " received.");

			if ( FilterIndex == 1 )
				WriteTextToFile(FileName, ThisGameLog.GetFile());
            else
				WriteCSVFile(FileName);
		}

		private void WriteCSVFile(string FileName)
		{
			StringBuilder FileText = new StringBuilder();
			StringBuilder LineText = new StringBuilder();

			int x = 1;

			foreach ( ListViewItem l in this.listViewCombatSummary.Items )
			{
				LineText.Append(l.SubItems[0].Text); // Time
				LineText.Append(",");
				LineText.Append(l.SubItems[1].Text); // Weapon
				LineText.Append(",");
				LineText.Append(l.SubItems[2].Text); // HitType
				LineText.Append(",");
				LineText.Append(l.SubItems[3].Text); // Target
				LineText.Append(",");
				LineText.Append(l.SubItems[4].Text); // Damage
				LineText.Append('\n');

				Debug.WriteLine(x.ToString() +":" + LineText.ToString());

				FileText.Append(LineText.ToString());
				LineText.Remove(0, LineText.Length);
			}

			WriteTextToFile(FileName, FileText.ToString());
		}

		private void WriteTextToFile(string FileName, string Text)
		{
			StreamWriter sr = File.CreateText(FileName);

			sr.Write(Text);
			sr.Close();
		}

		private void EnableComponents()
		{
			listViewCombatSummary.Enabled = true;
			btnHitTypeMenu.Enabled = true;
			btnWeaponFilter.Enabled = true;
			btnTargetFilter.Enabled = true;
			listView2.Enabled = true;
		}


		private void DoCombatLog(GameLog g)
		{
			if ( !g.IsCombatLog() )
				return;
		

			// Wire up progress events
			if ( CombatLogProcessStarted != null )
				g.ProcessingStarted += CombatLogProcessStarted;

			if ( CombatLogProcessUpdate != null )
                g.ProcessingUpdate += CombatLogProcessUpdate;

			if ( CombatLogProcessComplete != null )
				g.ProcessingComplete += CombatLogProcessComplete;

			CombatLogEntryCollection cl = g.GetCombatEntries();
		
			if ( cl != null )
			{
				PrepareCombatSummaryFilters(cl, g);
				DrawCombatSummary(cl);
			}
		}

		private void DrawCombatSummary(CombatLogEntryCollection cc)
		{
			listViewCombatSummary.Tag = cc;
			listViewCombatSummary.Items.Clear();
		
			CombatLogEntryCollection FilteredLog = GetFilteredCombatLog(cc);
		
			foreach ( CombatLogEntry c in FilteredLog )
			{
				ListViewItem l = new ListViewItem(new string[] { c.LogDTM.ToShortDateString() + " " + c.LogDTM.ToShortTimeString() + ":" + c.LogDTM.Second.ToString("00"), c.WeaponName, c.HitType.ToString(), c.TargetName, c.DamageCaused.ToString("0.0")} );
		
				l.ForeColor = GetHitTypeColor(c.HitType);
				l.Tag = c;
		
				listViewCombatSummary.Items.Add(l);
			}
		
			FilteredLog.GenerateWeaponStats();
			DrawWeaponSummary(FilteredLog);
			DrawOverallSummary(FilteredLog);
		}

		private void DrawWeaponGraph(WeaponSummary w, int Count)
		{
			// DeletePreviousGraphs();
			HGraph.ChartPane c = new HGraph.ChartPane();
			c.Chart1.ChartItems = new ChartItemCollection();

			c.PaneCaption2.Caption = w.WeaponName;

			foreach ( Object h in w.HitSummary.Keys )
			{
				HitTypeInfo ht = (HitTypeInfo)w.HitSummary[h];
				c.Chart1.ChartItems.Add(new ChartItem(h.ToString(), ht.DamageCaused));
			}

			int VerticalPosition;

			if ( GraphControls.Count == 0 )
				VerticalPosition = 8;
			else
			{
				HGraph.ChartPane cp = (HGraph.ChartPane)GraphControls[GraphControls.Count - 1].Control;
				VerticalPosition = cp.Location.Y + cp.Height + 16;
			}

			Debug.WriteLine("Creating graph control for " + w.WeaponName + " at " + VerticalPosition.ToString());

			c.Location = new Point(8,VerticalPosition);

			c.Chart1.CalculateBounds();
			c.Height = c.PaneCaption2.Size.Height + c.Chart1.Size.Height;
			c.Width = dockControl2.Width - 16;
			c.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;

			dockControl2.Controls.Add(c);
			GraphControls.Add(new GraphItem(GraphControls.LastSequenceID, (object)c));
		}

		
		private void DrawWeaponSummary(CombatLogEntryCollection cl)
		{
			listView2.Items.Clear();
			int TotalFired		= 0;
			int TotalHit		= 0;
			int TotalMissed		= 0;
			float TotalDamage	= 0.0F;
			float AverageDamage	= 0.0F;
			float PercentHit	= 0.0F;
			float PercentMissed	= 0.0F;
		
			foreach ( string WeaponName in cl.WeaponData.Keys )
			{
				WeaponSummary ws = (WeaponSummary)cl.WeaponData[WeaponName];
		
				ListViewItem l = new ListViewItem(new string[] {ws.WeaponName, ws.ShotsFired.ToString(), ws.ShotsHit.ToString(), ws.ShotsMissed.ToString(), ws.TotalDamage.ToString("0.00"), ws.AverageDamage.ToString("0.00"), ws.PercentageShotsHit.ToString("0.0%"),ws.PercentageShotsMissed.ToString("0.0%")});
				listView2.Items.Add(l);
		
				TotalFired += ws.ShotsFired;
				TotalHit += ws.ShotsHit;
				TotalMissed += ws.ShotsMissed;
				TotalDamage += (float)ws.TotalDamage;
				AverageDamage += (float)ws.AverageDamage;
				PercentHit += ws.PercentageShotsHit;
				PercentMissed += ws.PercentageShotsMissed;
			}
		
			ListViewItem ll = new ListViewItem(new string[] {""});
			listView2.Items.Add(ll);
		
			PercentHit = (float)TotalHit / (float)TotalFired;
			PercentMissed = (float)TotalMissed / (float)TotalFired;
		
			ll = new ListViewItem(new string[] {"Total",TotalFired.ToString(),TotalHit.ToString(), TotalMissed.ToString(), TotalDamage.ToString("0.00"), AverageDamage.ToString("0.00"), PercentHit.ToString("0.0%"),PercentMissed.ToString("0.0%") });
		
			listView2.Items.Add(ll);
		}

		private void DeletePreviousGraphs()
		{
			foreach ( GraphItem g in GraphControls )
			{
				dockControl2.Controls.Remove((Control)g.Control);
			}

			GraphControls.Clear();
		}

		private void DrawOverallSummary(CombatLogEntryCollection cl)
		{
			// For each Weapon
			// Draw proportional damage types
		
			richTextBoxSummary.Text = "";
		
			DeletePreviousGraphs();
		
			int WeaponCount = 0;
			foreach ( Object w in cl.WeaponData.Keys )
			{
				Debug.WriteLine("Weapon: " + w.ToString());
				richTextBoxSummary.Text += "\n" + w.ToString() + "\n\n";
		
				WeaponSummary ws = (WeaponSummary)cl.WeaponData[w];
		
				foreach (Object h in ws.HitSummary.Keys)
				{
					HitTypeInfo ht = (HitTypeInfo)ws.HitSummary[h];
					Debug.WriteLine("\tType: " + h.ToString() + " " + ht.HitCount + " / " + ht.DamageCaused);
					richTextBoxSummary.Text += "\t" + h.ToString() + "\t" + ht.HitCount + "\t" + ht.DamageCaused + "\n";
				}
		
				DrawWeaponGraph(ws, WeaponCount++);
		
				//				Debug.WriteLine("Wrecking: " + ws.Wrecking.HitCount + "/" + ws.Wrecking.DamageCount);
				//				Debug.WriteLine("Excellent: " + ws.Excellent.HitCount + "/" + ws.Excellent.DamageCount);
			}
		}

		private Color GetHitTypeColor(CombatLog.HitTypes HitType)
		{
			switch ( HitType )
			{
				case CombatLog.HitTypes.Wrecking:
					return Color.Red;

				case CombatLog.HitTypes.Excellent:
					return Color.Orange;

				case CombatLog.HitTypes.CloseMiss:
					return Color.Gray;

				case CombatLog.HitTypes.Miss:
					return Color.Gray;

				case CombatLog.HitTypes.Good:
					return Color.Green;

				default:
					return Color.Black;
			}
		}

		private CombatLogEntryCollection GetFilteredCombatLog(CombatLogEntryCollection cc)
		{
			CombatLogEntryCollection FilteredList = cc;
		
			if ( lblWeaponFilter.Text != "All" && lblWeaponFilter.Text.Length != 0 ) // 'All' is not selected
				FilteredList = FilteredList.FilterByWeapon(lblWeaponFilter.Text.Trim());
		
			if ( lblHitType.Text != "All" && lblHitType.Text.Length != 0 )
				FilteredList = FilteredList.FilterByHitType(lblHitType.Text.Trim());
		
			if ( lblTargetFilter.Text != "All" && lblTargetFilter.Text.Length != 0 )
				FilteredList = FilteredList.FilterByTarget(lblTargetFilter.Text.Trim());
		
			return FilteredList;
		}

		private void PrepareCombatSummaryFilters(CombatLogEntryCollection cc, GameLog g)
		{
			PrepareWeaponContextMenu(cc, g);
			PrepareHitTypeContextMenu(cc, g);
			PrepareTargetContextMenu(cc, g);
		}

		private void PrepareTargetContextMenu(CombatLogEntryCollection cc, GameLog g)
		{
			int newItem;
			contextMenuTarget.MenuItems.Clear();
			contextMenuTarget.Tag = (object)lblTargetFilter;
		
			newItem = contextMenuTarget.MenuItems.Add(new TD.SandBar.MenuButtonItem("All", new System.EventHandler(this.contextMenu_Activate)));
			contextMenuTarget.MenuItems[newItem].Checked = true;
		
			string[] Entries;

			if ( AllGameLogs.LogCache.Contains(g.FileName) )
			{
				CombatLogCache cache = AllGameLogs.LogCache[g.FileName];
				Entries = cache.TargetsAttacked;
			}
			else
			{
				Entries = cc.GetUniqueTargets();
			}
		
			int itemCount = 0;
			foreach (string s in Entries)
			{
				newItem = contextMenuTarget.MenuItems.Add(new TD.SandBar.MenuButtonItem(s, new System.EventHandler(this.contextMenu_Activate)));
		
				if ( itemCount == 0)
					contextMenuTarget.MenuItems[newItem].BeginGroup = true;
						
				itemCount++;
			}
		}
		
		private void PrepareWeaponContextMenu(CombatLogEntryCollection cc, GameLog g)
		{
			int newItem;
			contextMenuWeapon.MenuItems.Clear();
			contextMenuWeapon.Tag = (object)lblWeaponFilter;
		
			newItem = contextMenuWeapon.MenuItems.Add(new TD.SandBar.MenuButtonItem("All", new System.EventHandler(this.contextMenu_Activate)));
			contextMenuWeapon.MenuItems[newItem].Checked = true;

			string[] Entries;

			if ( AllGameLogs.LogCache.Contains(g.FileName) )
			{
				CombatLogCache cache = AllGameLogs.LogCache[g.FileName];
				Entries = cache.WeaponsUsed;
			}
			else
			{
				Entries = cc.GetUniqueWeaponsList();
			}
		
			// string[] Entries = cc.GetUniqueWeaponsList();
		
			int itemCount = 0;
			foreach (string s in Entries)
			{
				newItem = contextMenuWeapon.MenuItems.Add(new TD.SandBar.MenuButtonItem(s, new System.EventHandler(this.contextMenu_Activate)));
		
				if ( itemCount == 0)
					contextMenuWeapon.MenuItems[newItem].BeginGroup = true;
						
				itemCount++;
			}
		
		}
		
		private void PrepareHitTypeContextMenu(CombatLogEntryCollection cc, GameLog g)
		{
			int newItem;
			contextMenuHitTypes.MenuItems.Clear();
			contextMenuHitTypes.Tag = (object)lblHitType;
		
			newItem = contextMenuHitTypes.MenuItems.Add(new TD.SandBar.MenuButtonItem("All", new System.EventHandler(this.contextMenu_Activate)));
			contextMenuHitTypes.MenuItems[newItem].Checked = true;

			string[] Entries;

			if ( AllGameLogs.LogCache.Contains(g.FileName) )
			{
				CombatLogCache cache = AllGameLogs.LogCache[g.FileName];
				Entries = cache.HitTypes;
			}
			else
			{
				Entries = cc.GetUniqueHitTypes();
			}
				
			int itemCount = 0;
			foreach ( string s in Entries )
			{
				newItem = contextMenuHitTypes.MenuItems.Add(new TD.SandBar.MenuButtonItem(s, new System.EventHandler(this.contextMenu_Activate)));
		
				if ( itemCount == 0 )
					contextMenuHitTypes.MenuItems[newItem].BeginGroup = true;
		
				itemCount++;
			}
		}

		private void DrawFilterText(TD.SandBar.ContextMenuBarItem Menu)
		{
			Label tb = (Label)Menu.Tag;
			tb.Text = "";

			int i = 0;
			foreach ( TD.SandBar.MenuButtonItem m in Menu.MenuItems )
			{
				if ( m.Checked )
				{
					if ( i > 0 )
						tb.Text += "; ";

					tb.Text += m.Text;

					i++;
				}
			}
		}

		private bool TDMenuItemsChecked(TD.SandBar.ContextMenuBarItem menu)
		{
			bool itemsChecked = false;

			for (int i = 0; i < menu.MenuItems.Count; i++ )
			{
				if ( i > 0 )
				{
					if ( menu.MenuItems[i].Checked )
					{
						itemsChecked = true;
						break;
					}
				}
			}

			return itemsChecked;
		}

		private void TDClearSelectedItems(TD.SandBar.ContextMenuBarItem menu)
		{
			for (int i = 0; i < menu.MenuItems.Count; i++ )
				menu.MenuItems[i].Checked = false;
		}

		private void HandleContextMenuClick(TD.SandBar.ContextMenuBarItem Menu, TD.SandBar.MenuButtonItem Button)
		{
			Debug.WriteLine("Menu title = " + Menu.Text);

			Debug.WriteLine("Button = " + Button.Text);

			if ( Button.Text == "All" )
			{
				if ( Button.Checked )
					return;
				else
				{
					foreach ( TD.SandBar.MenuButtonItem mi in Menu.MenuItems )
					{
						mi.Checked = false;
					}

					Button.Checked = true;
				}
			}
			else
			{
				bool ControlPressed = (Control.ModifierKeys & Keys.Control) == Keys.Control;

				if ( Button.Checked )
				{
					Button.Checked = false;

					// Is anything else checked? If not, ensure that the All option is

					if ( !TDMenuItemsChecked(Menu) )
						Menu.MenuItems[0].Checked = true;
				}
				else
				{
					// Tick this item

					if ( !ControlPressed )
					{
						// Clear previously selected items
						TDClearSelectedItems(Menu);
					}

					Button.Checked = true;
					Menu.MenuItems[0].Checked = false; // Clear the 'All' option
				}
			}

			DrawFilterText(Menu);

			CombatLogEntryCollection cc = (CombatLogEntryCollection)listViewCombatSummary.Tag;
			DrawCombatSummary(cc);

		}

		private void contextMenu_Activate(object sender, System.EventArgs e)
		{
			TD.SandBar.MenuButtonItem m = (TD.SandBar.MenuButtonItem)sender;
			TD.SandBar.ContextMenuBarItem Menu = (TD.SandBar.ContextMenuBarItem)m.Parent;

			HandleContextMenuClick(Menu, m);

			//contextMenuWeapon.Show(btnWeaponFilter, new Point(btnWeaponFilter.Width, 0));
		}

		private void btnWeaponFilter_Click(object sender, System.EventArgs e)
		{
			contextMenuWeapon.Show(btnWeaponFilter, new Point(btnWeaponFilter.Width, 0));
		}

		private void btnHitTypeMenu_Click(object sender, System.EventArgs e)
		{
			contextMenuHitTypes.Show(btnHitTypeMenu, new Point(btnHitTypeMenu.Width, 0));
		}

		private void btnTargetFilter_Click(object sender, System.EventArgs e)
		{
			contextMenuTarget.Show(btnTargetFilter, new Point(btnTargetFilter.Width, 0));
		}

		private void menuItem4_Click(object sender, System.EventArgs e)
		{
			// File browser context menu

			if ( listViewCombatSummary.SelectedItems.Count != 1 )
				return;

			CombatLogEntry c = (CombatLogEntry)listViewCombatSummary.SelectedItems[0].Tag;

			string WeaponName = c.WeaponName;

			Process.Start("http://www.eve-i.com/home/crowley/page/page_objectsearch.php?q=" + c.WeaponName);
		}

		private void menuItem5_Click(object sender, System.EventArgs e)
		{
			// Find Target

			if ( listViewCombatSummary.SelectedItems.Count != 1 )
				return;

			CombatLogEntry c = (CombatLogEntry)listViewCombatSummary.SelectedItems[0].Tag;

			Process.Start("http://www.eve-i.com/home/crowley/page/page_objectsearch.php?q=" + c.TargetName);				
		}
	}
}
