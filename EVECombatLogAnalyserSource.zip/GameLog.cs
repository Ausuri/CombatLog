using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Diagnostics;

namespace CombatLog
{
	/// <summary>
	/// Summary description for GameLog.
	/// </summary>
	public class GameLog
	{
		private string _FileName;
		private long _FileSize;
		private DateTime _CreationTime;
		private DateTime _SessionStartedDTM;
		private string _Listener;
		private string _LeafName;
		private StringBuilder _LogFileText = new StringBuilder();

		public delegate void ProcessingStartedEvent(object Sender, GameLog GameLogObj);
		public event ProcessingStartedEvent ProcessingStarted = null;

		public delegate void ProcessingUpdateEvent(object Sender, GameLog GameLogObj, int PositionInFile);
		public event ProcessingUpdateEvent ProcessingUpdate = null;

		public delegate void ProcessingCompleteEvent(object Sender, GameLog GameLogObj);
		public event ProcessingCompleteEvent ProcessingComplete = null;

		#region Regular Expression - Verify combat log file
		public Regex VerifyCombatLog = new Regex(
			@"\[ (?<LogDTM>\d\d\d\d.\d\d.\d\d \d\d:\d\d:\d\d) \] \(combat\)"
			+ @".*?Your ",
			RegexOptions.IgnoreCase
			| RegexOptions.Compiled
			);
		#endregion
		
		#region Regular Expression - Extract File Headers
		private Regex RXChatHeaders = new Regex(
			@"Listener:(?<Listener>"
			+ @".*?)\x0d.*?Session started:(?<SessionStarted>.*?)\x0d",
			RegexOptions.IgnoreCase
			| RegexOptions.Multiline
			| RegexOptions.Singleline
			| RegexOptions.Compiled
			);
		#endregion

		#region Regular Expression Combat Log Parser
		//  using System.Text.RegularExpressions;

		/// <summary>
		///  Regular expression built for C# on: Thu, Jul 29, 2004, 04:11:36 PM
		///  Using Expresso Version: 2.0.1548, http://www.ultrapico.com
		///  
		///  A description of the regular expression:
		///  
		///  [
		///  [LogDTM]: A named capture group. [\d\d\d\d.\d\d.\d\d \d\d:\d\d:\d\d]
		///      \d\d\d\d.\d\d.\d\d \d\d:\d\d:\d\d
		///          Any digit
		///          Any digit
		///          Any digit
		///          Any digit
		///          Any character
		///          Any digit
		///          Any digit
		///          Any character
		///          Any digit
		///          Any digit
		///          Any digit
		///          Any digit
		///          :
		///          Any digit
		///          Any digit
		///          :
		///          Any digit
		///          Any digit
		///  \]\(
		///      ]
		///      (
		///  [LogEntryType]: A named capture group. [.*?]
		///      Any character, any number of repetitions, as few as possible
		///  \).*?Your
		///      )
		///      Any character, any number of repetitions, as few as possible
		///  [Weapon]: A named capture group. [.*?]
		///      Any character, any number of repetitions, as few as possible
		///  [HitType]: A named capture group. [(?:barely misses|barely scratches|glances off|hits|is well aimed at|lightly hits|misses|perfectly strikes|places an excellent hit on)]
		///      Match expression but don't capture it. [barely misses|barely scratches|glances off|hits|is well aimed at|lightly hits|misses|perfectly strikes|places an excellent hit on]
		///          Select from 9 alternatives
		///              barely misses
		///              barely scratches
		///              glances off
		///              hits
		///              is well aimed at
		///              lightly hits
		///              misses
		///              perfectly strikes
		///              places an excellent hit on
		///  [EnemyName]: A named capture group. [.*?]
		///      Any character, any number of repetitions, as few as possible
		///  Match expression but don't capture it. [, (inflicting|causing|doing|wrecking for) (?<Damage>\d*.\d*)|\x2e]
		///      Select from 2 alternatives
		///          , (inflicting|causing|doing|wrecking for) (?<Damage>\d*.\d*)
		///              ,
		///              [1]: A numbered capture group. [inflicting|causing|doing|wrecking for]
		///                  Select from 4 alternatives
		///                      inflicting
		///                      causing
		///                      doing
		///                      wrecking for
		///              [Damage]: A named capture group. [\d*.\d*]
		///                  \d*.\d*
		///                      Any digit, any number of repetitions
		///                      Any character
		///                      Any digit, any number of repetitions
		///          ASCII Hex 2e
		///  
		///  
		/// </summary>
		public Regex EVECombatLog = new Regex(
			@"\[ (?<LogDTM>\d\d\d\d.\d\d.\d\d \d\d:\d\d:\d\d) \] \((?<LogE"
			+ @"ntryType>.*?)\).*?Your (?<Weapon>.*?) (?<HitType>(?:barely m"
			+ @"isses|barely scratches|glances off|hits|is well aimed at|lig"
			+ @"htly hits|misses|perfectly strikes|places an excellent hit o"
			+ @"n)) (?<EnemyName>.*?)(?:, (inflicting|causing|doing|wrecking"
			+ @" for) (?<Damage>\d*.\d*)|\x2e)",
			RegexOptions.IgnoreCase
			| RegexOptions.Compiled
			);
		#endregion

		public GameLog()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public GameLog(string FileName)
		{
			_FileName = FileName;
		}

		public string GetFile()
		{
			if ( _LogFileText.Length == 0 )
				LoadFile();

			return _LogFileText.ToString();
		}
		
		public string GetLogText()
		{
			string s;

			if ( _LogFileText.Length == 0 )
				LoadFile();

			s = _LogFileText.ToString();

			_LogFileText.Remove(0, _LogFileText.Length);

			return s;
		}

		private void LoadFile()
		{

			if ( _LogFileText.Length != 0 )
				return;

			if (!File.Exists(_FileName)) 
				throw new Exception("The file " + _FileName + " does not exist. Aborting load for this object");

			try
			{
				StreamReader sr = File.OpenText(_FileName);

				_LogFileText.Append(sr.ReadToEnd());

				sr.Close();

				//Debug.WriteLine("File: " + _LeafName + " loaded");
			}
			catch (Exception e)
			{
				throw e;
			}
		}

		public bool IsCombatLog()
		{
			if ( _LogFileText.Length == 0 )
				LoadFile();

			if ( VerifyCombatLog.IsMatch(_LogFileText.ToString()) )
				return true;

			return false;
		}

		public void GetHeaders()
		{
			System.IFormatProvider format =
				new System.Globalization.CultureInfo("en-GB", true);

			string sessionStartedStr;

			if ( _LogFileText.Length == 0 )
				LoadFile();

			if ( RXChatHeaders.IsMatch(_LogFileText.ToString()) )
			{
				_Listener = RXChatHeaders.Match(_LogFileText.ToString()).Groups["Listener"].ToString().Trim();
				sessionStartedStr = RXChatHeaders.Match(_LogFileText.ToString()).Groups["SessionStarted"].ToString().Trim();

				//   Session started: 2004.04.28 00:05:12

				_SessionStartedDTM = DateTime.ParseExact(sessionStartedStr, "yyyy.M.d HH:mm:ss", format);
			}
			else
			{
				throw new Exception("No GameLog headers");
			}

			_LogFileText.Remove(0, _LogFileText.Length); // Dispose of the text from memory
		}

		public CombatLogEntryCollection GetCombatEntries()
		{
			if ( _LogFileText.Length == 0 )
				LoadFile();

			if ( !EVECombatLog.IsMatch(_LogFileText.ToString()) )
			{
				_LogFileText.Remove(0, _LogFileText.Length);
				return null;
			}

			CombatLogEntryCollection cc = new CombatLogEntryCollection();

			System.IFormatProvider format =
				new System.Globalization.CultureInfo("en-GB", true);

			string damageStr;

			Debug.WriteLine("About to parse combat log");
			Debug.WriteLine("Combat log file size is: " + this.FileSize.ToString());

			double percentageProcessed = 0.0F;
			double currentPosition;
			double fileSize = Convert.ToDouble(this.FileSize);

			if ( ProcessingStarted != null )
				ProcessingStarted(this, this);

			foreach ( Match m in EVECombatLog.Matches(_LogFileText.ToString()) )
			{
				CombatLogEntry c = new CombatLogEntry();

				c.LogDTM = DateTime.ParseExact(m.Groups["LogDTM"].Value, "yyyy.M.d HH:mm:ss", format);
				c.WeaponName = m.Groups["Weapon"].Value.ToString();
				c.HitDescription = m.Groups["HitType"].Value.ToString();
				c.TargetName = m.Groups["EnemyName"].Value.ToString();
				c.PositionInFile = m.Index;

				currentPosition = Convert.ToDouble(c.PositionInFile) + Convert.ToDouble(m.Length);

				percentageProcessed = currentPosition / fileSize;

                // Debug.WriteLine("Percentage Processed: " + percentageProcessed.ToString("0%") + " [" + m.Index + "]");

				if ( ProcessingUpdate != null )
					ProcessingUpdate(this, this, c.PositionInFile);

				c.MatchStringLength = m.Length;
			
				damageStr = m.Groups["Damage"].Value.ToString();

				try
				{
					c.DamageCaused = Convert.ToDouble(damageStr);
				}
				catch
				{
					c.Missed = true;
				}

				cc.Add(c);
			}

			if ( ProcessingComplete != null )
				ProcessingComplete(this, this);

			_LogFileText.Remove(0, _LogFileText.Length); // Dispose of the text from memory
			return cc;
		}

		public string FileName
		{
			get { return this._FileName; }
			set { this._FileName = value; }
		}

		public long FileSize
		{
			get { return this._FileSize; }
			set { this._FileSize = value; }
		}

		public DateTime CreationTime
		{
			get { return this._CreationTime; }
			set { this._CreationTime = value; }
		}

		public string LeafName
		{
			get { return this._LeafName; }
			set { this._LeafName = value; }
		}

		public string Listener
		{
			get { return this._Listener; }
			set { this._Listener = value; }
		}

		public System.DateTime SessionStartedDTM
		{
			get { return this._SessionStartedDTM; }
			set { this._SessionStartedDTM = value; }
		}
	}
}
