using System;
using System.Windows.Forms;

namespace CombatLog
{
	public class ProgressStatus : StatusBar
	{
		private int _progressBarPanel = -1;
		public ProgressBar progressBar = new ProgressBar();

		public ProgressStatus()
		{
			progressBar.Hide();
			this.Controls.Add(progressBar);
			this.DrawItem += new StatusBarDrawItemEventHandler(this.Reposition);
		}

		public int setProgressBarPanel
		{
			//
			// Property to tell the StatusBar which panel to use for the ProgressBar.
			//
			get { return _progressBarPanel; }
			set 
			{
				_progressBarPanel = value;
				this.Panels[_progressBarPanel].Style = StatusBarPanelStyle.OwnerDraw;
			}
		}

		private void Reposition(object sender, StatusBarDrawItemEventArgs sbdevent)
		{
			progressBar.Location = new System.Drawing.Point(sbdevent.Bounds.X, sbdevent.Bounds.Y);
			progressBar.Size = new System.Drawing.Size(sbdevent.Bounds.Width, sbdevent.Bounds.Height);
			progressBar.Show();
		}
	}
}
