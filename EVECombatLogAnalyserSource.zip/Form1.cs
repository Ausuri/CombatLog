using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Xml.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;

namespace CombatLog
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private GraphItemCollection GraphControls = new GraphItemCollection();
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		private GameLogCollection GameLogs = new GameLogCollection();
		private System.Windows.Forms.RichTextBox richTextBox2;
		private System.Windows.Forms.MenuItem menuItem6;
		private System.Windows.Forms.MenuItem menuItem9;
		private System.Windows.Forms.MenuItem menuItem10;
		private TD.SandBar.ContextMenuBarItem contextMenuBarItem1;
		private TD.SandBar.MenuButtonItem menuButtonItem2;
		private TD.SandBar.MenuButtonItem menuButtonItem3;
		private TD.SandBar.MenuButtonItem menuButtonItem4;
		private System.Windows.Forms.Panel panelFileListMain;
		private System.Windows.Forms.ListView listView1;
		private System.Windows.Forms.ColumnHeader Date;
		private System.Windows.Forms.ColumnHeader columnHeader2;
		private System.Windows.Forms.ColumnHeader columnHeader1;
		private System.Windows.Forms.Panel panelFileListTop;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.ComboBox comboBoxListener;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.ComboBox comboBoxLogAge;
		private System.Windows.Forms.Button button1;
		private TD.SandDock.SandDockManager sandDockManager1;
		private TD.SandDock.DockContainer leftSandDock;
		private TD.SandDock.DockContainer rightSandDock;
		private TD.SandDock.DockContainer bottomSandDock;
		private TD.SandDock.DockContainer topSandDock;
		private TD.SandDock.DockControl dockControl1;
		public FileViewListItemComparer FileBrowserComparer = new FileViewListItemComparer();

		private string ApplicationDataDirectory	= Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + @"\EVECombatLog\";

		private ProgressStatus statusBar = new ProgressStatus();
		private System.Windows.Forms.StatusBarPanel pnl1;
		private System.Windows.Forms.StatusBarPanel statusBarPanel1;
		private System.Windows.Forms.MenuItem old_old_menuItem7;
		private System.Windows.Forms.ContextMenu contextMenuFile1;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.MenuItem menuItem8;
		private System.Windows.Forms.MenuItem menuItemWindow;
		private System.Windows.Forms.MenuItem menuItemCascade;
		private System.Windows.Forms.MenuItem menuItemTileHoriz;
		private System.Windows.Forms.MenuItem menuItemTileVert;
		private System.Windows.Forms.MenuItem menuItemExport;
		private System.Windows.Forms.SaveFileDialog saveFileDialog1;
		private System.Windows.Forms.MenuItem menuItem1About;
		private System.Windows.Forms.StatusBarPanel pnlProgress;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.richTextBox2 = new System.Windows.Forms.RichTextBox();
			this.menuItem6 = new System.Windows.Forms.MenuItem();
			this.menuItem9 = new System.Windows.Forms.MenuItem();
			this.menuItem10 = new System.Windows.Forms.MenuItem();
			this.contextMenuBarItem1 = new TD.SandBar.ContextMenuBarItem();
			this.menuButtonItem2 = new TD.SandBar.MenuButtonItem();
			this.menuButtonItem3 = new TD.SandBar.MenuButtonItem();
			this.menuButtonItem4 = new TD.SandBar.MenuButtonItem();
			this.panelFileListMain = new System.Windows.Forms.Panel();
			this.listView1 = new System.Windows.Forms.ListView();
			this.Date = new System.Windows.Forms.ColumnHeader();
			this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
			this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
			this.contextMenuFile1 = new System.Windows.Forms.ContextMenu();
			this.old_old_menuItem7 = new System.Windows.Forms.MenuItem();
			this.panelFileListTop = new System.Windows.Forms.Panel();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.comboBoxListener = new System.Windows.Forms.ComboBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.comboBoxLogAge = new System.Windows.Forms.ComboBox();
			this.button1 = new System.Windows.Forms.Button();
			this.sandDockManager1 = new TD.SandDock.SandDockManager();
			this.leftSandDock = new TD.SandDock.DockContainer();
			this.dockControl1 = new TD.SandDock.DockControl();
			this.rightSandDock = new TD.SandDock.DockContainer();
			this.bottomSandDock = new TD.SandDock.DockContainer();
			this.topSandDock = new TD.SandDock.DockContainer();
			this.statusBar = new CombatLog.ProgressStatus();
			this.pnl1 = new System.Windows.Forms.StatusBarPanel();
			this.pnlProgress = new System.Windows.Forms.StatusBarPanel();
			this.statusBarPanel1 = new System.Windows.Forms.StatusBarPanel();
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.menuItemExport = new System.Windows.Forms.MenuItem();
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.menuItemWindow = new System.Windows.Forms.MenuItem();
			this.menuItemCascade = new System.Windows.Forms.MenuItem();
			this.menuItemTileHoriz = new System.Windows.Forms.MenuItem();
			this.menuItemTileVert = new System.Windows.Forms.MenuItem();
			this.menuItem8 = new System.Windows.Forms.MenuItem();
			this.menuItem1About = new System.Windows.Forms.MenuItem();
			this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
			this.panelFileListMain.SuspendLayout();
			this.panelFileListTop.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.leftSandDock.SuspendLayout();
			this.dockControl1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pnl1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pnlProgress)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel1)).BeginInit();
			this.SuspendLayout();
			// 
			// richTextBox2
			// 
			this.richTextBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.richTextBox2.BackColor = System.Drawing.SystemColors.Control;
			this.richTextBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.richTextBox2.Cursor = System.Windows.Forms.Cursors.Default;
			this.richTextBox2.Location = new System.Drawing.Point(8, 16);
			this.richTextBox2.Name = "richTextBox2";
			this.richTextBox2.ReadOnly = true;
			this.richTextBox2.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
			this.richTextBox2.Size = new System.Drawing.Size(272, 76);
			this.richTextBox2.TabIndex = 0;
			this.richTextBox2.Text = "some text";
			this.richTextBox2.WordWrap = false;
			// 
			// menuItem6
			// 
			this.menuItem6.Index = -1;
			this.menuItem6.Text = "";
			// 
			// menuItem9
			// 
			this.menuItem9.Index = -1;
			this.menuItem9.Text = "Foo";
			// 
			// menuItem10
			// 
			this.menuItem10.Index = -1;
			this.menuItem10.Text = "Bar";
			// 
			// contextMenuBarItem1
			// 
			this.contextMenuBarItem1.MenuItems.AddRange(new TD.SandBar.MenuButtonItem[] {
																							this.menuButtonItem2,
																							this.menuButtonItem3,
																							this.menuButtonItem4});
			this.contextMenuBarItem1.Text = "(contextMenu1)";
			// 
			// menuButtonItem2
			// 
			this.menuButtonItem2.Checked = true;
			this.menuButtonItem2.Text = "425mm Proto Gauss Railgun";
			// 
			// menuButtonItem3
			// 
			this.menuButtonItem3.Text = "425 Compressed Coil Railgun";
			// 
			// menuButtonItem4
			// 
			this.menuButtonItem4.Text = "Modulated Heavy Neutron Blaster";
			// 
			// panelFileListMain
			// 
			this.panelFileListMain.BackColor = System.Drawing.SystemColors.Info;
			this.panelFileListMain.Controls.Add(this.listView1);
			this.panelFileListMain.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panelFileListMain.Location = new System.Drawing.Point(0, 104);
			this.panelFileListMain.Name = "panelFileListMain";
			this.panelFileListMain.Size = new System.Drawing.Size(276, 514);
			this.panelFileListMain.TabIndex = 7;
			// 
			// listView1
			// 
			this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																						this.Date,
																						this.columnHeader2,
																						this.columnHeader1});
			this.listView1.ContextMenu = this.contextMenuFile1;
			this.listView1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.listView1.FullRowSelect = true;
			this.listView1.HideSelection = false;
			this.listView1.Location = new System.Drawing.Point(0, 0);
			this.listView1.Name = "listView1";
			this.listView1.Size = new System.Drawing.Size(276, 514);
			this.listView1.TabIndex = 1;
			this.listView1.View = System.Windows.Forms.View.Details;
			this.listView1.ItemActivate += new System.EventHandler(this.listView1_ItemActivate);
			this.listView1.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.listView1_ColumnClick);
			this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
			// 
			// Date
			// 
			this.Date.Text = "Date";
			this.Date.Width = 112;
			// 
			// columnHeader2
			// 
			this.columnHeader2.Text = "Char";
			this.columnHeader2.Width = 82;
			// 
			// columnHeader1
			// 
			this.columnHeader1.Text = "Size";
			this.columnHeader1.Width = 75;
			// 
			// contextMenuFile1
			// 
			this.contextMenuFile1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																							 this.old_old_menuItem7});
			// 
			// old_old_menuItem7
			// 
			this.old_old_menuItem7.Index = 0;
			this.old_old_menuItem7.Text = "Open in text editor";
			this.old_old_menuItem7.Click += new System.EventHandler(this.menuItem7_Click_1);
			// 
			// panelFileListTop
			// 
			this.panelFileListTop.Controls.Add(this.groupBox1);
			this.panelFileListTop.Dock = System.Windows.Forms.DockStyle.Top;
			this.panelFileListTop.Location = new System.Drawing.Point(0, 0);
			this.panelFileListTop.Name = "panelFileListTop";
			this.panelFileListTop.Size = new System.Drawing.Size(276, 104);
			this.panelFileListTop.TabIndex = 8;
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.comboBoxListener);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Controls.Add(this.comboBoxLogAge);
			this.groupBox1.Controls.Add(this.button1);
			this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.groupBox1.Location = new System.Drawing.Point(0, 0);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(276, 104);
			this.groupBox1.TabIndex = 5;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Filter";
			// 
			// comboBoxListener
			// 
			this.comboBoxListener.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.comboBoxListener.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxListener.Items.AddRange(new object[] {
																  "All",
																  "Last 30 Days",
																  "Last 7 Days",
																  "Today"});
			this.comboBoxListener.Location = new System.Drawing.Point(96, 39);
			this.comboBoxListener.Name = "comboBoxListener";
			this.comboBoxListener.Size = new System.Drawing.Size(168, 21);
			this.comboBoxListener.Sorted = true;
			this.comboBoxListener.TabIndex = 3;
			// 
			// label1
			// 
			this.label1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.label1.Location = new System.Drawing.Point(8, 16);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(88, 23);
			this.label1.TabIndex = 4;
			this.label1.Text = "Show logs from";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label2
			// 
			this.label2.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.label2.Location = new System.Drawing.Point(8, 43);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(88, 23);
			this.label2.TabIndex = 4;
			this.label2.Text = "Character";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// comboBoxLogAge
			// 
			this.comboBoxLogAge.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.comboBoxLogAge.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBoxLogAge.Items.AddRange(new object[] {
																"All",
																"Today",
																"Last 7 Days",
																"Last 30 Days"});
			this.comboBoxLogAge.Location = new System.Drawing.Point(96, 13);
			this.comboBoxLogAge.Name = "comboBoxLogAge";
			this.comboBoxLogAge.Size = new System.Drawing.Size(168, 21);
			this.comboBoxLogAge.TabIndex = 3;
			// 
			// button1
			// 
			this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.button1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.button1.Location = new System.Drawing.Point(192, 68);
			this.button1.Name = "button1";
			this.button1.TabIndex = 0;
			this.button1.Text = "Refresh";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// sandDockManager1
			// 
			this.sandDockManager1.OwnerForm = this;
			// 
			// leftSandDock
			// 
			this.leftSandDock.Controls.Add(this.dockControl1);
			this.leftSandDock.Dock = System.Windows.Forms.DockStyle.Left;
			this.leftSandDock.Guid = new System.Guid("e8c4835f-04b5-4d28-9941-e763ada515db");
			this.leftSandDock.LayoutSystem = new TD.SandDock.SplitLayoutSystem(250, 400, System.Windows.Forms.Orientation.Horizontal, new TD.SandDock.LayoutSystemBase[] {
																																											 new TD.SandDock.ControlLayoutSystem(276, 659, new TD.SandDock.DockControl[] {
																																																															 this.dockControl1}, this.dockControl1)});
			this.leftSandDock.Location = new System.Drawing.Point(0, 0);
			this.leftSandDock.Manager = this.sandDockManager1;
			this.leftSandDock.Name = "leftSandDock";
			this.leftSandDock.Size = new System.Drawing.Size(280, 659);
			this.leftSandDock.TabIndex = 13;
			// 
			// dockControl1
			// 
			this.dockControl1.Closable = false;
			this.dockControl1.Controls.Add(this.panelFileListMain);
			this.dockControl1.Controls.Add(this.panelFileListTop);
			this.dockControl1.Guid = new System.Guid("1958cef5-c709-41c5-8d14-930f85041f02");
			this.dockControl1.Location = new System.Drawing.Point(0, 18);
			this.dockControl1.Name = "dockControl1";
			this.dockControl1.Size = new System.Drawing.Size(276, 618);
			this.dockControl1.TabIndex = 0;
			this.dockControl1.Text = "Combat Log Browser";
			// 
			// rightSandDock
			// 
			this.rightSandDock.Dock = System.Windows.Forms.DockStyle.Right;
			this.rightSandDock.Guid = new System.Guid("d454a83d-9985-4536-ad97-bc50464253b6");
			this.rightSandDock.LayoutSystem = new TD.SandDock.SplitLayoutSystem(250, 400);
			this.rightSandDock.Location = new System.Drawing.Point(1200, 0);
			this.rightSandDock.Manager = this.sandDockManager1;
			this.rightSandDock.MaximumSize = 600;
			this.rightSandDock.Name = "rightSandDock";
			this.rightSandDock.Size = new System.Drawing.Size(0, 659);
			this.rightSandDock.TabIndex = 14;
			// 
			// bottomSandDock
			// 
			this.bottomSandDock.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.bottomSandDock.Guid = new System.Guid("bee2eff7-dcee-4a93-8b02-543ae8c129a4");
			this.bottomSandDock.LayoutSystem = new TD.SandDock.SplitLayoutSystem(250, 400);
			this.bottomSandDock.Location = new System.Drawing.Point(0, 659);
			this.bottomSandDock.Manager = this.sandDockManager1;
			this.bottomSandDock.Name = "bottomSandDock";
			this.bottomSandDock.Size = new System.Drawing.Size(1200, 0);
			this.bottomSandDock.TabIndex = 15;
			// 
			// topSandDock
			// 
			this.topSandDock.Dock = System.Windows.Forms.DockStyle.Top;
			this.topSandDock.Guid = new System.Guid("bf5d1e6d-4847-4734-b8ff-53842b9fbec2");
			this.topSandDock.LayoutSystem = new TD.SandDock.SplitLayoutSystem(250, 400);
			this.topSandDock.Location = new System.Drawing.Point(0, 0);
			this.topSandDock.Manager = this.sandDockManager1;
			this.topSandDock.Name = "topSandDock";
			this.topSandDock.Size = new System.Drawing.Size(1200, 0);
			this.topSandDock.TabIndex = 16;
			// 
			// statusBar
			// 
			this.statusBar.Location = new System.Drawing.Point(0, 659);
			this.statusBar.Name = "statusBar";
			this.statusBar.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
																						 this.pnl1,
																						 this.pnlProgress,
																						 this.statusBarPanel1});
			this.statusBar.setProgressBarPanel = 1;
			this.statusBar.ShowPanels = true;
			this.statusBar.Size = new System.Drawing.Size(1200, 22);
			this.statusBar.TabIndex = 0;
			// 
			// pnl1
			// 
			this.pnl1.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Contents;
			this.pnl1.MinWidth = 130;
			this.pnl1.Width = 130;
			// 
			// pnlProgress
			// 
			this.pnlProgress.MinWidth = 100;
			this.pnlProgress.Style = System.Windows.Forms.StatusBarPanelStyle.OwnerDraw;
			// 
			// statusBarPanel1
			// 
			this.statusBarPanel1.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring;
			this.statusBarPanel1.Width = 954;
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem1,
																					  this.menuItemWindow,
																					  this.menuItem8});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItemExport,
																					  this.menuItem2});
			this.menuItem1.Text = "File";
			this.menuItem1.Popup += new System.EventHandler(this.menuItem1_Popup);
			// 
			// menuItemExport
			// 
			this.menuItemExport.Index = 0;
			this.menuItemExport.Text = "Export...";
			this.menuItemExport.Click += new System.EventHandler(this.menuItemExport_Click);
			// 
			// menuItem2
			// 
			this.menuItem2.Index = 1;
			this.menuItem2.ShowShortcut = false;
			this.menuItem2.Text = "Exit";
			this.menuItem2.Click += new System.EventHandler(this.menuItem2_Click);
			// 
			// menuItemWindow
			// 
			this.menuItemWindow.Index = 1;
			this.menuItemWindow.MdiList = true;
			this.menuItemWindow.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						   this.menuItemCascade,
																						   this.menuItemTileHoriz,
																						   this.menuItemTileVert});
			this.menuItemWindow.Text = "Window";
			// 
			// menuItemCascade
			// 
			this.menuItemCascade.Index = 0;
			this.menuItemCascade.Text = "Cascade";
			this.menuItemCascade.Click += new System.EventHandler(this.menuItemCascade_Click);
			// 
			// menuItemTileHoriz
			// 
			this.menuItemTileHoriz.Index = 1;
			this.menuItemTileHoriz.Text = "Tile Horizontally";
			this.menuItemTileHoriz.Click += new System.EventHandler(this.menuItemTileHoriz_Click);
			// 
			// menuItemTileVert
			// 
			this.menuItemTileVert.Index = 2;
			this.menuItemTileVert.Text = "Tile Vertically";
			this.menuItemTileVert.Click += new System.EventHandler(this.menuItemTileVert_Click);
			// 
			// menuItem8
			// 
			this.menuItem8.Index = 2;
			this.menuItem8.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem1About});
			this.menuItem8.Text = "Help";
			// 
			// menuItem1About
			// 
			this.menuItem1About.Index = 0;
			this.menuItem1About.Text = "About Combat Analyser...";
			this.menuItem1About.Click += new System.EventHandler(this.menuItem1About_Click);
			// 
			// saveFileDialog1
			// 
			this.saveFileDialog1.Filter = "Text File|*.txt|CSV|*.csv";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(1200, 681);
			this.Controls.Add(this.leftSandDock);
			this.Controls.Add(this.rightSandDock);
			this.Controls.Add(this.bottomSandDock);
			this.Controls.Add(this.topSandDock);
			this.Controls.Add(this.statusBar);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.IsMdiContainer = true;
			this.Menu = this.mainMenu1;
			this.Name = "Form1";
			this.Text = "EVE Combat Log Analyzer";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.panelFileListMain.ResumeLayout(false);
			this.panelFileListTop.ResumeLayout(false);
			this.groupBox1.ResumeLayout(false);
			this.leftSandDock.ResumeLayout(false);
			this.dockControl1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pnl1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pnlProgress)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel1)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		[STAThread]

		static void Main() 
		{
			Application.EnableVisualStyles();
			Application.DoEvents();
			Application.Run(new Form1());
		}

		private CombatLogCacheCollection GetCombatLogCache()
		{

			CombatLogCacheCollection c = new CombatLogCacheCollection();

			FileStream fs;
			try
			{
				fs = new FileStream(ApplicationDataDirectory + "LogCache.xml", FileMode.Open);
			}
			catch (Exception e)
			{
				Debug.WriteLine("Problem opening log cache: " + e.ToString());
				return null;
			}

			XmlSerializer xs = new XmlSerializer(typeof(CombatLogCacheCollection));

			CombatLogCacheCollection logCache;
			try
			{
				logCache = (CombatLogCacheCollection)xs.Deserialize(fs);
			}
			catch
			{
				// Something went wrong loading the cache
				// return an empty log cache
				logCache = new CombatLogCacheCollection();
			}

			fs.Close();
			return logCache;
		}

		private void SaveGameLogCache(GameLogCollection gl)
		{
			if ( !Directory.Exists(ApplicationDataDirectory) )
				Directory.CreateDirectory(ApplicationDataDirectory);

			FileStream fs = new FileStream(ApplicationDataDirectory + "logCache.xml", FileMode.Create);

			XmlSerializer xs = new XmlSerializer(typeof(CombatLogCacheCollection));

			xs.Serialize(fs, gl.LogCache);

			fs.Close();

		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			FileBrowserComparer.CurrentSortColumn = 0;
			FileBrowserComparer.SortOrder = SortOrder.Descending;
			listView1.ListViewItemSorter = FileBrowserComparer;

			PrepareFileBrowser();
		}

		private void LogFileLoaded_Event(object Sender, GameLog EventArgs, int CurrentFile, int TotalFiles)
		{
			//Debug.WriteLine("Gamelog loaded: " + EventArgs.FileName);
			bool Abort;
			UpdateFileBrowser(EventArgs, CurrentFile, TotalFiles, out Abort);
		}

		private delegate void UpdateFileBrowserDelegate(GameLog LogFile, int CurrentFile, int TotalFiles, out bool UserAbortRequest);
		private void UpdateFileBrowser(GameLog LogFile, int CurrentFile, int TotalFiles, out bool UserAbortRequest)
		{
			if ( !listView1.InvokeRequired )
			{
				lock(this)
				{
					GameLog gl = LogFile;

					pnl1.Text = "Processed " + (CurrentFile + 1).ToString() + " / " + TotalFiles.ToString();
					this.statusBar.progressBar.Increment(1);
					// progressBar1.Increment(1);

					// UserAbortRequest = ( _RunState != RunState.Running );
					UserAbortRequest = false;

					if ( gl.IsCombatLog() )
					{
						ListViewItem l = new ListViewItem(new string[] { gl.SessionStartedDTM.ToShortDateString() + " " + gl.SessionStartedDTM.ToShortTimeString(), gl.Listener, gl.FileSize.ToString()} );
						l.Tag = gl;
						listView1.Items.Add(l);

						listView1.Sort();
					}

					// Debug.WriteLine("Add: " + LogFile.FileName);
				}
			}
			else
			{
				object inOutAbortRequest = false;

				UpdateFileBrowserDelegate bc = new UpdateFileBrowserDelegate(UpdateFileBrowser);
				Invoke(bc, new object[] { LogFile, CurrentFile, TotalFiles, inOutAbortRequest });

				UserAbortRequest = (bool)inOutAbortRequest;
			}
		}

		private delegate void EnumerateDelegate();
		private void Enumerate()
		{
			listView1.Items.Clear();
			Debug.WriteLine("About to enumerate log files");
			GameLogs.EnumerateGameLogDir();
		}

		private void ProcessingComplete_Event(object Sender, System.EventArgs e)
		{
			SaveGameLogCache(GameLogs);
			PrepareAgeFilter();
			PrepareListenersFilter();

			GameLogs.LogFileProcessed_Event		-= new GameLogCollection.LogFileProcessedEvent(LogFileLoaded_Event);
			GameLogs.ProcessingComplete_Event	-= new GameLogCollection.LogFileProcessingComplete(ProcessingComplete_Event);
			GameLogs.ProcessingStarted_Event	-= new GameLogCollection.LogFileProcessingStarting(ProcessingStarted_Event);

			Debug.WriteLine("Disabling the progress bar now");

			pnl1.Text = "Cache refreshed";
			statusBar.progressBar.Value=0;
			
		}

		private void ProcessingStarted_Event(object Sender, int FileCount)
		{
			this.statusBar.progressBar.Minimum = 0;
			this.statusBar.progressBar.Maximum = FileCount;
			this.statusBar.progressBar.Value = 0;
			this.statusBar.setProgressBarPanel = 1;
			pnl1.Text = "Processed 0/" + FileCount.ToString();
		}

		private void PrepareFileBrowser()
		{
			listView1.SuspendLayout();
            listView1.Items.Clear();
			listView1.ResumeLayout();

			comboBoxListener.Items.Clear();
			comboBoxLogAge.Items.Clear();

			this.statusBar.progressBar.Value = 0;
			
			GameLogs.Clear();

			if ( GameLogs.LogCache != null )
				GameLogs.LogCache.Clear();

			CombatLogCacheCollection logCache = GetCombatLogCache();

			if ( logCache == null )
				logCache = new CombatLogCacheCollection();

			GameLogs.LogCache = logCache;

			GameLogs.LogFileProcessed_Event += new GameLogCollection.LogFileProcessedEvent(LogFileLoaded_Event);
			GameLogs.ProcessingComplete_Event += new GameLogCollection.LogFileProcessingComplete(ProcessingComplete_Event);
			GameLogs.ProcessingStarted_Event += new GameLogCollection.LogFileProcessingStarting(ProcessingStarted_Event);

			EnumerateDelegate DoEnumeration = new EnumerateDelegate(Enumerate);

			DoEnumeration.BeginInvoke(null, null);

		}

		private void PrepareAgeFilter()
		{
			//comboBoxLogAge.SelectedIndexChanged 
			this.comboBoxLogAge.SelectedIndexChanged -= new System.EventHandler(this.comboBoxLogAge_SelectedIndexChanged);

			comboBoxLogAge.BeginUpdate();
			comboBoxLogAge.Items.Clear();
			comboBoxLogAge.Items.AddRange(new string[] { "All", "Today", "Last 7 Days", "Last 30 Days" });
			comboBoxLogAge.SelectedIndex = 0;
			comboBoxLogAge.EndUpdate();

			this.comboBoxLogAge.SelectedIndexChanged += new System.EventHandler(this.comboBoxLogAge_SelectedIndexChanged);

		}

		private void PrepareListenersFilter()
		{
			// Get a list of distinct listeners
			this.comboBoxListener.SelectedIndexChanged -= new System.EventHandler(this.comboBoxListener_SelectedIndexChanged);

			comboBoxListener.BeginUpdate();
			comboBoxListener.Items.Clear();
			comboBoxListener.Items.Add("All");
			comboBoxListener.Items.AddRange(GameLogs.GetUniqueListeners());
			comboBoxListener.SelectedIndex = 0;
			comboBoxListener.EndUpdate();

			this.comboBoxListener.SelectedIndexChanged += new System.EventHandler(this.comboBoxListener_SelectedIndexChanged);

		}

		private int GetDaysFromAgeCombo()
		{
			int days = -1;

			switch ( comboBoxLogAge.SelectedItem.ToString() )
			{
				case "All":
					days = -1;
					break;
				case "Today":
					days = 0;
					break;

				case "Last 7 Days":
					days = 7;
					break;

				case "Last 30 Days":
					days = 30;
					break;
			}

			return days;
		}

		private void RedrawFileList()
		{
			listView1.Items.Clear();

			int Days = GetDaysFromAgeCombo();

			GameLogCollection FilteredLogs = new GameLogCollection();

			//
			// Apply the day filter
			//
			if ( Days != -1 )
				FilteredLogs = GameLogs.FilterBy(Days);
			else
				FilteredLogs = GameLogs;

			//
			// Apply the Listener Filter
			//
			if ( comboBoxListener.SelectedItem != null )
			{
				if ( comboBoxListener.SelectedItem.ToString() != "All" )
					FilteredLogs = FilteredLogs.FilterBy(comboBoxListener.SelectedItem.ToString());
			}

			//
			// Update the listview
			//
			listView1.BeginUpdate();
			listView1.SuspendLayout();

			listView1.Items.AddRange(GetFileItems(FilteredLogs));

			listView1.ResumeLayout();
			listView1.EndUpdate();
		}

		private ListViewItem[] GetFileItems(GameLogCollection Logs)
		{
			ListViewItem[] lvis = new ListViewItem[Logs.Count];

			int i = 0;
			foreach ( GameLog gl in Logs )
			{
				ListViewItem l = new ListViewItem(new string[] { gl.SessionStartedDTM.ToShortDateString() + " " + gl.SessionStartedDTM.ToShortTimeString(), gl.Listener, gl.FileSize.ToString()} );
				l.Tag = gl;

				lvis[i++] = l;
			}

			return lvis;
		}

		private void DoFileBrowserSort(int ColumnID)
		{
			if ( FileBrowserComparer.CurrentSortColumn == ColumnID )
			{
				if ( FileBrowserComparer.SortOrder == System.Windows.Forms.SortOrder.Ascending )
					FileBrowserComparer.SortOrder = System.Windows.Forms.SortOrder.Descending;
				else
					FileBrowserComparer.SortOrder = System.Windows.Forms.SortOrder.Ascending;
			}
			else
				FileBrowserComparer.SortOrder = System.Windows.Forms.SortOrder.Ascending;

			FileBrowserComparer.CurrentSortColumn = ColumnID;

			listView1.ListViewItemSorter = FileBrowserComparer;
			listView1.Sort();
			
			if ( listView1.SelectedItems.Count == 1 )
				listView1.EnsureVisible(listView1.SelectedItems[0].Index);
		}

		private Color GetHitTypeColor(CombatLog.HitTypes HitType)
		{
			switch ( HitType )
			{
				case CombatLog.HitTypes.Wrecking:
					return Color.Red;

				case CombatLog.HitTypes.Excellent:
					return Color.Orange;

				case CombatLog.HitTypes.CloseMiss:
					return Color.Gray;

				case CombatLog.HitTypes.Miss:
					return Color.Gray;

				case CombatLog.HitTypes.Good:
					return Color.Green;

				default:
					return Color.Black;
			}
		}


		#region Event Handlers



		private void listView1_ColumnClick(object sender, System.Windows.Forms.ColumnClickEventArgs e)
		{
			DoFileBrowserSort(e.Column);
		}

		private void listView1_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if ( listView1.SelectedItems.Count == 1 )
			{
				GameLog g = (GameLog)listView1.SelectedItems[0].Tag;

//				richTextBoxFileSummary.Clear();
//				richTextBoxFileSummary.SelectionFont = new Font("Microsoft Sans Serif",8, FontStyle.Bold);
//				richTextBoxFileSummary.SelectedText = g.LeafName;
//				richTextBoxFileSummary.SelectionFont = new Font("Microsoft Sans Serif",8, FontStyle.Regular);
//				richTextBoxFileSummary.SelectedText = "\n\nCreated on " + g.SessionStartedDTM.ToLongDateString();
//				richTextBoxFileSummary.SelectedText = "\n\nListener " + g.Listener;
			}
		}

		private void CombatLogProcessingStarted(object Sender, GameLog Log)
		{
			statusBar.progressBar.Value = 0;
			statusBar.progressBar.Minimum = 0;
			statusBar.progressBar.Maximum = (int)Log.FileSize;
		}

		private void UpdateCombatLogProcessingStatus(object Sender, GameLog Log, int PositionInFile)
		{
			statusBar.progressBar.Value = PositionInFile;
			//statusBar.progressBar.Update();
		}

		private void CombatLogProcessingComplete(object Sender, GameLog Log)
		{
			statusBar.progressBar.Value = 0;
			pnl1.Text = "Combat log loaded";
			//statusBar.progressBar.Update();
		}

		private Form LogFileOpen(GameLog g)
		{
			foreach ( Form f in this.MdiChildren )
			{
				if ( g == (GameLog)f.Tag )
					return f;
			}

			return null;
		}

		private void listView1_ItemActivate(object sender, System.EventArgs e)
		{
			if ( listView1.SelectedItems.Count == 1 )
			{
				GameLog g = (GameLog)listView1.SelectedItems[0].Tag;

				Form logWindow = LogFileOpen(g);

				if ( logWindow != null )
				{
					logWindow.BringToFront();
					return;
				}

				g.GetFile();

				Form2 f = new Form2();
				f.Tag = g;
				f.MdiParent = this;
				f.Text = g.LeafName + " [" + g.Listener + "]";
				f.AllGameLogs = GameLogs;
				f.ThisGameLog = g;
				// f.Dock = DockStyle.Fill;

				f.CombatLogProcessStarted += new GameLog.ProcessingStartedEvent(CombatLogProcessingStarted);
				f.CombatLogProcessUpdate += new GameLog.ProcessingUpdateEvent(UpdateCombatLogProcessingStatus);
				f.CombatLogProcessComplete += new GameLog.ProcessingCompleteEvent(CombatLogProcessingComplete);

				if ( this.MdiChildren.Length > 0 )
					f.WindowState = this.MdiChildren[0].WindowState;
				else
					f.WindowState = FormWindowState.Maximized;


				f.Show();
			}
		}


		private void comboBoxListener_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			RedrawFileList();		
		}

		private void comboBoxLogAge_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			RedrawFileList();
		}

		private void menuItem1_Click(object sender, System.EventArgs e)
		{
			if ( listView1.SelectedItems.Count != 1 )
				return;

			GameLog l = (GameLog)listView1.SelectedItems[0].Tag;
			Process.Start(l.FileName);

		}


		#endregion

		private void button1_Click(object sender, System.EventArgs e)
		{
			PrepareFileBrowser();
		}

		private void menuItem7_Click_1(object sender, System.EventArgs e)
		{
			// File browser context menu

			if ( listView1.SelectedItems.Count != 1 )
				return;

			GameLog l = (GameLog)listView1.SelectedItems[0].Tag;

			Process.Start(l.FileName);
		}

		private void menuItemCascade_Click(object sender, System.EventArgs e)
		{
			this.LayoutMdi(MdiLayout.Cascade);
		}

		private void menuItemTileHoriz_Click(object sender, System.EventArgs e)
		{
			this.LayoutMdi(MdiLayout.TileHorizontal);
		}

		private void menuItemTileVert_Click(object sender, System.EventArgs e)
		{
			this.LayoutMdi(MdiLayout.TileVertical);
		}

		private void menuItemExport_Click(object sender, System.EventArgs e)
		{
			if ( this.ActiveMdiChild == null )
				return;

			Form2 f = (Form2)this.ActiveMdiChild;

			saveFileDialog1.Title = "Export " + f.Text;
			saveFileDialog1.FileName = Path.ChangeExtension(f.ThisGameLog.FileName, null);

			DialogResult r = saveFileDialog1.ShowDialog();

			Debug.WriteLine("Dialog result = " + r.ToString());

			if ( r == DialogResult.OK )
			{
				f.ExportFile(saveFileDialog1.FileName, saveFileDialog1.FilterIndex);
			}
		}

		private void menuItem1_Popup(object sender, System.EventArgs e)
		{
			if ( this.ActiveMdiChild == null )
				menuItemExport.Enabled = false;
			else
				menuItemExport.Enabled = true;
		}

		private void menuItem1About_Click(object sender, System.EventArgs e)
		{
			AboutForm f = new AboutForm();
			f.StartPosition = FormStartPosition.CenterParent;
			f.ShowDialog();
		}

		private void menuItem2_Click(object sender, System.EventArgs e)
		{
			Application.Exit();
		}
	}
}
