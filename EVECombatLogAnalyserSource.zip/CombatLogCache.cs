using System;

namespace CombatLog
{
	/// <summary>
	/// Summary description for CombatLogCache.
	/// </summary>
	[Serializable()]
	public class CombatLogCache
	{
		private DateTime _CreationTime;
		private long _FileSize;
		private string _FileName;
		private string _LeafName;
		private bool _IsCombatLog;

		private string _Character;
		private string[] _WeaponsUsed;
		private string[] _TargetsAttacked;
		private string[] _HitTypes;

		public CombatLogCache()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public CombatLogCache(string FileName, long FileSize, DateTime CreationTime, bool CombatLogBoo)
		{
			_FileName = FileName;
			_FileSize = FileSize;
			_CreationTime = CreationTime;
			_IsCombatLog = CombatLogBoo;
		}

		public System.DateTime CreationTime
		{
			get { return this._CreationTime; }
			set { this._CreationTime = value; }
		}

		public string[] TargetsAttacked
		{
			get { return this._TargetsAttacked; }
			set { this._TargetsAttacked = value; }
		}

		public string[] HitTypes
		{
			get { return this._HitTypes; }
			set { this._HitTypes = value; }
		}

		public string FileName
		{
			get { return this._FileName; }
			set { this._FileName = value; }
		}

		public string[] WeaponsUsed
		{
			get { return this._WeaponsUsed; }
			set { this._WeaponsUsed = value; }
		}

		public string Character
		{
			get { return this._Character; }
			set { this._Character = value; }
		}

		public string LeafName
		{
			get { return this._LeafName; }
			set { this._LeafName = value; }
		}

		public long FileSize
		{
			get { return this._FileSize; }
			set { this._FileSize = value; }
		}

		public bool IsCombatLog
		{
			get { return _IsCombatLog; }
			set { _IsCombatLog = value; }
		}
	}
}
