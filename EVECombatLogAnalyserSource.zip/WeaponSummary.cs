using System;
using System.Diagnostics;
using System.Collections;

namespace CombatLog
{

	public class HitTypeInfo
	{
		private int _HitCount;
		private double _DamageCaused;

		public HitTypeInfo()
		{
		}

		public HitTypeInfo(int HitCount, double DamageCaused)
		{
			_HitCount = HitCount;
			_DamageCaused = DamageCaused;
		}

		public int HitCount
		{
			get { return _HitCount; }
			set { _HitCount = value; }
		}

		public double DamageCaused
		{
			get { return _DamageCaused; }
			set { _DamageCaused = value; }
		}
	}

	/// <summary>
	/// Summary description for WeaponSummary.
	/// </summary>
	public class WeaponSummary
	{
		string	_WeaponName;
		int		_ShotsFired;
		int		_ShotsHit;
		int		_ShotsMissed;
		double	_TotalDamage;
		double	_AverageDamage;
		float	_PercentageShotsHit;
		float	_PercentageShotsMissed;

		public Hashtable HitSummary = new Hashtable();

		public WeaponSummary()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		
		public double TotalDamage
		{
			get { return this._TotalDamage; }
			set { this._TotalDamage = value; }
		}

		public float PercentageShotsHit
		{
			get { return (float)(((float)_ShotsHit / (float)_ShotsFired)); }
			set { this._PercentageShotsHit = value; }
		}

		public float PercentageShotsMissed
		{
			get { return (float)(((float)_ShotsMissed / (float)_ShotsFired)); }
			set { this._PercentageShotsMissed = value; }
		}

		public double AverageDamage
		{
			get { return this._TotalDamage / this._ShotsFired; }
			set { this._AverageDamage = value; }
		}

		public string WeaponName
		{
			get { return this._WeaponName; }
			set { this._WeaponName = value; }
		}

		public int ShotsFired
		{
			get { return this._ShotsFired; }
			set { this._ShotsFired = value; }
		}

		public int ShotsHit
		{
			get { return _ShotsHit; }
			set { _ShotsHit = value; }
		}

		public int ShotsMissed
		{
			get { return _ShotsMissed; }
			set { _ShotsMissed = value; }
		}
	}
}
